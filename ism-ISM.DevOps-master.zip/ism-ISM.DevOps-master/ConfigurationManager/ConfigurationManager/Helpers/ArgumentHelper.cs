﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConfigurationManager.Globals;

namespace ConfigurationManager.Helpers
{
    public class ArgumentHelper
    {
        private String[] _data;
        private Dictionary<string, string>  _arguments = new Dictionary<string, string>();
        public Boolean validity;
        public ArgumentHelper(String[] data)
        {
            _data = data;
            _arguments = parse();
            validity = validate(_arguments);
        }

        public Dictionary<string, string> get()
        {
            return _arguments;
        }

        Dictionary<string, string> parse()
        {
            Dictionary<string, string> arguments = new Dictionary<string, string>();
            foreach (string argument in _data)
            {
                string[] splitted = argument.Split('=');

                if (splitted.Length == 2)
                {
                    arguments[splitted[0]] = splitted[1];
                }
            }
            return arguments;
        }

        Boolean validate(Dictionary<string, string> data)
        {
            String[] acceptedArguments = Settings.acceptedArguments;
            Boolean validity = true;
            string message = String.Empty;
            List<string> argumentKeys = new List<string>(data.Keys);
            foreach (String key in acceptedArguments)
            {
                var keyValidity = argumentKeys.Contains(key);
                validity = validity && keyValidity;
                if (keyValidity == false)
                {
                    message += "\n" + key + " argument is missing. ";
                    Console.WriteLine(key + " argument is missing.");
                }
            }
            //if (validity != true)
            //{
            //    Console.WriteLine(message);
            //    throw new Exception(message);
            //}
            return validity;
        }

    }
}
