import { Component } from '@angular/core';
import { LoaderService } from './services/controls/loader.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ResourceManager';

  constructor(
    public loader: LoaderService
  ) {

  }
}
