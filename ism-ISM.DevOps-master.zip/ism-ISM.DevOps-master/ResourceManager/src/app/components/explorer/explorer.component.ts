import { Overlay } from '@angular/cdk/overlay';
import { FormEditorComponent } from './../form-editor/form-editor.component';
import { ImportComponent } from './../import/import.component';
import { createSpreadsheetData } from 'handsontable/helpers';
import { FlatTreeControl, NestedTreeControl } from '@angular/cdk/tree';
import { NONE_TYPE } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { MatTreeFlatDataSource, MatTreeFlattener, MatTreeNestedDataSource } from '@angular/material/tree';
import Handsontable from 'handsontable/base';
import { ContextMenu } from 'handsontable/plugins/contextMenu';
import { FormService } from 'src/app/services/api/form.service';
import { LoaderService } from 'src/app/services/controls/loader.service';
import { Columns, Config, DefaultConfig } from 'ngx-easy-table';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-explorer',
  templateUrl: './explorer.component.html',
  styleUrls: ['./explorer.component.scss']
})
export class ExplorerComponent implements OnInit {


  TREE_DATA: any[] = [];

  ngOnInit(): void {
    this.get_list();
    this.configuration = { ...DefaultConfig };
    this.data = this.data;
    this.rows = this.data;
    this.get_schema();
    this.get_table(this.activeNode.landscape);
    this.configuration.rows = window.innerHeight>1000?15:5;

  }

  constructor(
    private api: FormService,
    public loader: LoaderService,
    public dialog: MatDialog,
    public overlay: Overlay
  ) {
    this.dataSource.data = this.TREE_DATA;
  }

  openDialog() {
    this.dialog.open(ImportComponent);
  }

  //#region Finder

  private _transformer = (node: any, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level
    };
  };

  treeControl = new NestedTreeControl<FlatNode>(node => node.children);
  dataSource = new MatTreeNestedDataSource<FlatNode>();

  activeNode = {name: 'test', landscape: 'test'};

  hasChild = (_: number, node: FlatNode) => !!node.children && node.children.length > 0;

  get_list() {
    this.loader.show();
    this.api.getLandscapes().subscribe(
      (data: any) => {
        this.dataSource.data = data;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  //#endregion Finder

  //#region Table

  public columns: any[] = [];
  data: any[] = [];
  rows: any[] = [];
  public configuration: Config = { ...DefaultConfig };

  onApplicationSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.rows = this.data.filter((_) => _.application.toLowerCase().indexOf(value) > -1);
  }

  onNamespaceSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.rows = this.data.filter((_) => _.namespace.toLowerCase().indexOf(value) > -1);
  }

  os = ['win', 'linux'];
  onOSFilter(event: Event): void {
    this.rows = this.data.filter((_) => _.os == event);
  }

  reset(): void {
    this.rows = this.data;
  }

  get_schema() {
    this.loader.show();
    this.api.getSchema().subscribe(
      (data: any) => {
        this.columns = data;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_table(landscape: string) {
    this.loader.show();
    this.api.getTable(landscape).subscribe(
      (data: any) => {
        this.data = data;
        this.reset();
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  onEvent(event: { event: string; value: any }): void {
    const selected = event.value.row;
    console.log(selected['application']);
    console.log(this.activeNode.landscape);
    const currentDialog = this.dialog.open(FormEditorComponent, {
      scrollStrategy: this.overlay.scrollStrategies.noop(),
      data: {
        application: selected['application'],
        landscape: this.activeNode.landscape
      },
    });
    currentDialog.afterClosed().subscribe(() => {
      this.get_table(this.activeNode.landscape);
    });
  }

  //#endregion Table

  LoadData(node: any) {
    console.log(node);
    this.activeNode = node;
    this.get_schema();
    this.get_table(node.landscape);
  }
}

interface FlatNode {
  name: string;
  children?: FlatNode[];
  data?: string;
}

export interface Company {
  application: string;
  cpu: number;
}
