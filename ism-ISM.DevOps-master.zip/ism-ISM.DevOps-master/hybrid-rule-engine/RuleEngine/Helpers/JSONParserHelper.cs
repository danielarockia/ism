﻿using BetterConsoleTables;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using static RuleEngine.Controllers.Logging;

namespace RuleEngine.Helpers
{
    public static class JSONParserHelper
    {
        public static Dictionary<string, string> Parse(string data)
        {
            Dictionary<string, string> activeTenants = new Dictionary<string, string>();
            Table table = new Table("SL", "Tenant", "Vanity URL", "Client Authentication Key");
            table.Config = TableConfiguration.MySql();
            try
            {
                var tenantConfigs = (JArray)(JsonConvert.DeserializeObject<dynamic>(data).tenantConfigs);

                for (int i = 0; i < tenantConfigs.Count; i++)
                {
                    var node = tenantConfigs[i];

                        string tenantUrl = node["tenantUrl"].ToString();
                        string clientAuthenticationKey = node["clientAuthenticationKey"].ToString();
                        string status = node["status"].ToString();
                        if (status != "Active")
                            continue;
                        var vanityUrls = node["alternateUrls"].ToArray();
                        foreach (var url in vanityUrls)
                        {
                            activeTenants.Add(url.ToString(), clientAuthenticationKey);
                        }
                        table.AddRow(i + 1, tenantUrl, vanityUrls.Count(), clientAuthenticationKey);
                        activeTenants.Add(tenantUrl, clientAuthenticationKey);
                }
            }
            catch(Exception ex)
            {
                Log($"Error parsing ccf response: {ex.Message} {ex.StackTrace}", LogLevel.Error);
            }
            Console.Write(table.ToString());

            return activeTenants;
        }        
    }
}
