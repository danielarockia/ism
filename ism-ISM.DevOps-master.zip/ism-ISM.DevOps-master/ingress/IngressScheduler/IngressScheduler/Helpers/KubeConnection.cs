﻿using IngressScheduler.Controller;
using IngressScheduler.Interfaces;
using IngressScheduler.Models;
using k8s;

namespace IngressScheduler.Helpers
{
    public class KubeConnection
    {
        public static IKubernetes Connect(ISettings settings, string mode = null)
        {
            if(mode == null){
                mode = settings.Load("mode");
                Logging.Log("MODE=" + mode, Logging.LogLevel.Info);
            }
            string configFilePath = settings.Load("configFilePath");
            //string configFilePath = @"/app/";

            //foreach (DictionaryEntry e in System.Environment.GetEnvironmentVariables())
            //{
            //    Console.WriteLine(e.Key + ":" + e.Value);
            //}

            KubernetesClientConfiguration config = new KubernetesClientConfiguration();
            
            if (mode == Modes.Production)
            {
                if (!CheckConfig.exists(settings, configFilePath))
                {
                    return null;
                }
                config = KubernetesClientConfiguration.BuildConfigFromConfigFile(configFilePath + settings.Load("kubeconfigfile"));
            }
            else if (mode == Modes.Debug)
            {
                configFilePath = "..\\..\\..\\..\\";
                if (CheckConfig.exists(settings, configFilePath))
                {
                    config = KubernetesClientConfiguration.BuildConfigFromConfigFile(configFilePath + settings.Load("kubeconfigfile"));
                }
                else
                {
                    config = KubernetesClientConfiguration.BuildDefaultConfig();
                }
            }
            else if (mode == Modes.Cluster)
            {
                config = KubernetesClientConfiguration.InClusterConfig();
            }
            else if (mode == Modes.Test)
            {
                config = KubernetesClientConfiguration.InClusterConfig();
                IngressCompose.prefix = Modes.Test.ToLower() + "-";
            }
            else
            {
                Logging.Log("No Connection Method Selected", Logging.LogLevel.Error);
                return null;
            }

            IKubernetes client = new Kubernetes(config);
            return client;
        }
    }
}
