﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationManager.Models
{
    public class Property
    {
        public string type="property";
        public string path;
        public string selector;
        public string selectorValue;
        public string value;
    }
}
