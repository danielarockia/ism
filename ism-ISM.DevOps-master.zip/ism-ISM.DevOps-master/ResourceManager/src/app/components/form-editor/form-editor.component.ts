import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormService } from 'src/app/services/api/form.service';
import { LoaderService } from 'src/app/services/controls/loader.service';

@Component({
  selector: 'app-form-editor',
  templateUrl: './form-editor.component.html',
  styleUrls: ['./form-editor.component.scss']
})
export class FormEditorComponent implements OnInit {

  constructor(
    private api: FormService,
    public loader: LoaderService,
    private _snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<FormEditorComponent>,
    @Inject(MAT_DIALOG_DATA) public appdata: FormSource
  ) { }

  ngOnInit(): void {
    console.log(this.appdata);
    this.get_form(this.appdata.landscape, this.appdata.application);
  }

  form_data: any;
  ready = false;

  get_form(landscape: string, application: string) {
    // this.loader.show();
    this.api.getForm(landscape, application).subscribe(
      (data: any) => {
        this.form_data = data;
        this.ready = true;
        // this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  submit(data: any) {
    this.loader.show();
    this.api.updateForm(this.appdata.landscape, this.appdata.application, data).subscribe(
      (data: any) => {
        const message = data;
        this.openSnackBar(message);
        this.dialogRef.close();
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
        this.openSnackBar('Changes not saved.');
      }
    );
  }

  openSnackBar(message: string) {
    this._snackBar.open(
      message,
      'Dismiss',
      {
        horizontalPosition: 'center',
        verticalPosition: 'top',
      });
  }
}

export interface FormSource {
  landscape: any;
  application: any;
}
