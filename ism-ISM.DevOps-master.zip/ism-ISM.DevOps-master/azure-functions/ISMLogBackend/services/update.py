import azure.functions as func
import requests
from database.insert import configure, update
import global_vars as globals
import json

def updateTracked(data):
    print('DATA:')
    data = json.loads(data)
    print(data)
    res = update(globals.TABLE_TRACKED, 'landscape', globals.LANDSCAPE, data)
    return func.HttpResponse (
        json.dumps({
            'updated': res
        }),
        status_code=200
    )

def updateWorkflow(data):
    data = json.loads(data)
    res = update(globals.TABLE_WORKFLOW, 'landscape', globals.LANDSCAPE, data)
    return func.HttpResponse (
        json.dumps({
            'updated': res
        }),
        status_code=200
    )