import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rollout',
  templateUrl: './rollout.component.html',
  styleUrls: ['./rollout.component.scss']
})
export class RolloutComponent implements OnInit {

  constructor(
    private route: Router,
  ) { }

  ngOnInit(): void {
  }

  plans = [
    'ISM Core Container',
    'Externam Services'
  ]

  openPlan(){
    console.log('open');

    this.route.navigate(['RolloutPlan']);
  }

}
