from datetime import datetime
from dateutil import parser

import os
import json
import sys

from kubernetes import client, config
from kubernetes.client.rest import ApiException
from kubernetes.client.api import core_v1_api
from kubernetes.stream import stream
from pymongo import database

import helpers.auth as auth
import helpers.kube as kube
import helpers.file_handling as file_handler
import helpers.driver as driver

import global_vars as globals
from database.get import filterOne
from database.insert import configure

def collectData():
    landscape   =   globals.LANDSCAPE
    interval    =   globals.INTERVAL
    status = filterOne(globals.TABLE_LANDSCAPE, 'landscape', landscape)
    if status==None: 
        status = dict()
        status['interval'] = interval
        status['landscape'] = landscape
    else:
        interval = status['interval']
        if (datetime.now()-status['update_timestamp']).total_seconds() < interval*60:
            return ({
                'updated'       :   False,
                'timestamp'     :   str(status['update_timestamp']),
                'interval'      :   interval
            })

    pods        =   {'landscape': landscape, 'data' : dict()}
    deployments =   {'landscape': landscape, 'data' : dict()}
    services    =   {'landscape': landscape, 'data' : dict()}
    res = True

    for namespace in globals.namespaces:
        pods_row, deployments_row, services_row = driver.fullCheck(namespace, globals.v1)
        pods['data'][namespace]           =   pods_row
        deployments['data'][namespace]    =   deployments_row
        services['data'][namespace]       =   services_row

    status['update_timestamp'] = datetime.now()
    pods_res = configure(globals.TABLE_PODS, 'landscape', landscape, pods)
    deployments_res = configure(globals.TABLE_DEPLOYMENTS, 'landscape', landscape, deployments)
    services_res = configure(globals.TABLE_SERVICES, 'landscape', landscape, services)
    res = res and configure(globals.TABLE_LANDSCAPE, 'landscape', landscape, status)

    return({
        'updated'       :   res,
        'timestamp'     :   str(status['update_timestamp']),
        'interval'      :   interval
    })