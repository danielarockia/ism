from distutils.log import debug
from kubernetes import client, config
from prettytable import PrettyTable
import time
import globals

config.load_kube_config(config_file='~/.kube/config')
if globals.DEBUG:
    config.load_kube_config(context='AKS-RG-'+globals.DEBUG_LANDSCAPE+'-ISM-admin')
api_instance = client.CoreV1Api()

def getCachedImages(node_list, show_table=False):
    count = 0
    table = PrettyTable()
    table.field_names = ["#", "Node", "Image", "Size"]
    node_map = dict()
    node_list = api_instance.list_node()
    for node in node_list.items:
        if(node.metadata.labels['kubernetes.io/os'] == 'windows'):
            nodeName = node.metadata.name
            images = node.status.images
            # print("Node: %s" % (name))
            for image in images:
                if (image.names!=None and len(image.names)>1):
                    if 'sm.' in image.names[1]:
                        count += 1
                        imageName = image.names[1].split('/')[1]
                        imageSize = image.size_bytes
                        imageSize /= 1024*1024*1024
                        imageSize = round(imageSize, 2)
                        imageSize = str(imageSize) + ' GB'
                        table.add_row([count, nodeName, imageName, imageSize])
                        if imageName not in node_map:
                            node_map[imageName] = []
                        node_map[imageName].append(nodeName)
    if show_table:
        print(table)
    return node_map

def searchImage(node_map, node_list, image):
    node_count = 0
    for node in node_list.items:
        if node.metadata.labels['kubernetes.io/os'] == 'windows':
            node_count+=1
    if image in node_map:
        progress = (len(node_map[image])+0.0)/node_count
        return progress
    else:
        return 0

def watch(name, image):
    show_table = True
    progress = 0
    while progress<1:
        node_list = api_instance.list_node()
        node_map = getCachedImages(node_list, show_table)
        progress = searchImage(node_map, node_list, name+':'+image)
        print("Progress = %d%%" % (progress*100), flush=True)
        show_table = False
        time.sleep(10)
# watch()