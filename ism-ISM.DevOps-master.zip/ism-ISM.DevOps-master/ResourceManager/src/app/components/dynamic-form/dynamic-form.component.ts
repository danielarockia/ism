import { Component, OnInit } from '@angular/core';
import { FormService } from 'src/app/services/api/form.service';
import { LoaderService } from 'src/app/services/controls/loader.service';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit {
  landscapes: string[] = ['nvz-ci', 'ldz-devprd', 'nvz-prf', 'test'];
  applications: string[] = ['appserver', 'analyst', 'botservice', 'centralconfig', 'chat', 'messagequeue', 'test'];
  landscape = 'nvz-ci';
  application = 'centralconfig';

  constructor(
    private api: FormService,
    public loader: LoaderService
  ) { }

  ngOnInit(): void {
    this.get_form();
  }

  form_data: any;
  ready = false;

  get_form() {
    this.loader.show();
    this.api.getForm(this.landscape, this.application).subscribe(
      (data: any) => {
        this.form_data = data;
        this.ready = true;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  updateFilter(){
    this.get_form();
  }
}
