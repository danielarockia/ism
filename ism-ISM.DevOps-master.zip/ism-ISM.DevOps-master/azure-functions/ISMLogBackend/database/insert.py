from datetime import datetime
import ISMLogBackend.database.auth as auth

def timeseries(table, data):
    db = auth.getDatabase()
    collection = db[table]
    data['time'] = datetime.now()
    res = collection.insert_one(data)
    return res.acknowledged

def timeseriesMany(table, data):
    db = auth.getDatabase()
    collection = db[table]
    current_time = datetime.now()
    for row_index in range(len(data)):
        data[row_index]['time'] = current_time
    res = collection.insert_many(data)
    return res.acknowledged

def configure(table, key, value, data):
    db = auth.getDatabase()
    collection = db[table]
    data['time'] = datetime.now()
    res = collection.update_one({key: value}, {"$set": data}, upsert=True)
    return res.acknowledged

def update(table, key, value, data):
    db = auth.getDatabase()
    collection = db[table]
    res = collection.update_one({key: value}, {"$set": {'data': data}}, upsert=True)
    return res.acknowledged