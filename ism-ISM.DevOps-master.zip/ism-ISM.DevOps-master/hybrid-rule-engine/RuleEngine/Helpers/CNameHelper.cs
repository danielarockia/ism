﻿
using RuleEngine.Interfaces;
using static RuleEngine.Controllers.Logging;

namespace RuleEngine.Helpers
{
    public static class CNameHelper
    {
        private static void WriteToHosts(string line, ISettings settings)
        {
            //if (settings.Load("mode") == "Debug")
            //    return;
            File.AppendAllText(@"etc/hosts", line + Environment.NewLine);
            Log("Host Entry Added : " + line, LogLevel.Info);
        }

        public static void Create(string cname, string ip, ISettings settings)
        {
            WriteToHosts(ip + "\t" + cname, settings);
        }
    }
}
