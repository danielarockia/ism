﻿using BetterConsoleTables;
using IngressScheduler.Helpers;
using IngressScheduler.Interfaces;
using IngressScheduler.Models;
using k8s;
using System;
using System.Collections.Generic;
using System.Linq;
using Action = IngressScheduler.Models.Action;

namespace IngressScheduler.Controller
{
    internal class RulesController
    {
        public static Table CreateTable(List<string> tenants)
        {
            Table table = new Table("#", "Host");
            for (int i = 0; i < tenants.Count(); i++)
            {
                table.AddRow(i + 1, tenants[i]);
            }
            table.Config = TableConfiguration.MySql();
            Logging.Log("\n\n" + table.ToString(), Logging.LogLevel.Info);
            return table;
        }

        public static void GetFinalActionList(ISettings settings, IKubernetes client, List<string> tenants, List<Ingress> ingressList, out Dictionary<string, List<Action>> actionTargets, out Dictionary<string, int> actions)
        {
            actionTargets = new Dictionary<string, List<Models.Action>>();
            actions = new Dictionary<string, int>();

            Dictionary<string, List<string>> actionExistingTargets = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> actionExistingRootTargets = new Dictionary<string, List<string>>();

            Dictionary<string, bool> staticApplications = new Dictionary<string, bool>();
            Dictionary<string, bool> staticApplicationsRoot = new Dictionary<string, bool>();

            List<string> applications = Applications.applicationList.Keys.ToList();

            ProcessExistingRules(
                settings,
                client,
                ingressList,
                ref actionExistingTargets,
                ref actionExistingRootTargets,
                ref staticApplications,
                ref staticApplicationsRoot
            );

            ProcessNewStaticRules(client, ref staticApplications, ref staticApplicationsRoot);

            Logging.Log("Existing Targets...", Logging.LogLevel.Debug);
            Debug.printTargets(actionExistingTargets);
            Logging.Log("Existing Root Targets...", Logging.LogLevel.Debug);
            Debug.printTargets(actionExistingRootTargets);

            // Process Existing Tenants
            actionTargets = ProcessExistingTargets(
                applications,
                actionExistingTargets,
                actionExistingRootTargets,
                actionTargets
            );

            // Process Deleted Tenants
            ProcessDeletedTenants(
                tenants,
                ingressList,
                ref actions,
                actionTargets,
                ref actionExistingTargets
            );

            // Process New Tenants
            actionTargets = ProcessNewTenant(
                applications,
                tenants,
                ref actions,
                actionTargets
            );
        }

        public static void ProcessExistingRules(
            ISettings settings,
            IKubernetes client,
            List<Ingress> ingressList,
            ref Dictionary<string, List<string>> actionExistingTargets,
            ref Dictionary<string, List<string>> actionExistingRootTargets,
            ref Dictionary<string, bool> staticApplications,
            ref Dictionary<string, bool> staticApplicationsRoot
        )
        {
            foreach (string appName in Applications.staticApplicationList.Keys)
            {
                staticApplications[appName] = false;
                staticApplicationsRoot[appName] = false;
            }

            Logging.Log("Processing Ingress Rules...", Logging.LogLevel.Debug);
            foreach (Ingress ingress in ingressList)
            {
                Logging.Log(ingress.Name + ":type:" + ingress.Type, Logging.LogLevel.Info);
                if (ingress.Type == IngressType._static)
                {
                    StaticRules.Process(settings, ingress, client);
                    if (ingress.Root == true)
                    {
                        staticApplicationsRoot[ingress.Application] = true;
                    }
                    else
                    {
                        staticApplications[ingress.Application] = true;
                    }
                }
                if (ingress.Type == IngressType.whitelist)
                {
                    if (ingress.Root == true)
                    {
                        if (!actionExistingRootTargets.ContainsKey(ingress.Host))
                        {
                            actionExistingRootTargets.Add(ingress.Host, new List<string>());
                        }
                        actionExistingRootTargets[ingress.Host].Add(ingress.Application);
                    }
                    else
                    {
                        if (!actionExistingTargets.ContainsKey(ingress.Host))
                        {
                            actionExistingTargets.Add(ingress.Host, new List<string>());
                        }
                        actionExistingTargets[ingress.Host].Add(ingress.Application);
                    }
                }
                Console.WriteLine("");
            }
            if (ingressList.Count == 0) Logging.Log("0 Rules", Logging.LogLevel.Info);
            Console.WriteLine("");
        }

        public static void ProcessNewStaticRules(
            IKubernetes client,
            ref Dictionary<string, bool> staticApplications,
            ref Dictionary<string, bool> staticApplicationsRoot
        )
        {
            Logging.Log("Precessing New Static Applications...", Logging.LogLevel.Info);
            foreach (string appName in staticApplications.Keys)
            {
                if (!staticApplications[appName])
                {
                    Logging.Log(appName, Logging.LogLevel.Info);
                    StaticRules.Create(appName, client);
                }
                if (!staticApplicationsRoot[appName])
                {
                    Logging.Log(appName + "[root]", Logging.LogLevel.Info);
                    StaticRules.Create(appName, client, root: true);
                }
            }
            if (staticApplications.Count == 0) Logging.Log("0 Rules", Logging.LogLevel.Info);
        }

        public static Dictionary<string, List<Action>> ProcessExistingTargets(
            List<string> applications,
            Dictionary<string, List<string>> actionExistingTargets,
            Dictionary<string, List<string>> actionExistingRootTargets,
            Dictionary<string, List<Action>> actionTargets
        )
        {
            foreach (var target in actionExistingTargets)
            {
                if (!actionTargets.ContainsKey(target.Key))
                {
                    actionTargets.Add(target.Key, new List<Action>());
                }
                foreach (string application in applications)
                {
                    Action action = new Action(application);
                    if (!target.Value.Contains(action.Application))
                    {
                        actionTargets[target.Key].Add(action);
                    }
                }
            }
            foreach (var target in actionExistingRootTargets)
            {
                if (!actionTargets.ContainsKey(target.Key))
                {
                    actionTargets.Add(target.Key, new List<Action>());
                }
                foreach (string application in applications)
                {
                    Action action = new Action(application, isRoot: true);
                    if (!target.Value.Contains(action.Application))
                    {
                        actionTargets[target.Key].Add(action);
                    }
                }
            }
            return actionTargets;
        }

        public static void ProcessDeletedTenants(
            List<string> tenants,
            List<Ingress> ingressList,
            ref Dictionary<string, int> actions,
            Dictionary<string, List<Action>> actionTargets,
            ref Dictionary<string, List<string>> actionExistingTargets
        )
        {
            Logging.Log("Process Deleted Tenants...", Logging.LogLevel.Info);
            foreach (Ingress ingress in ingressList)
            {

                if (tenants.Contains(ingress.Host))
                {
                    Logging.Log("ingress:" + ingress.Host + ":" + ingress.Application + ":active", Logging.LogLevel.Debug);
                    if (actionTargets[ingress.Host].Count == 0)
                    {
                        if (!actions.ContainsKey(ingress.Host))
                        {
                            actions.Add(ingress.Host, 0);
                        }
                    }
                    else
                    {
                        if (!actions.ContainsKey(ingress.Host))
                        {
                            actions.Add(ingress.Host, 2);
                        }
                    }
                }
                else if (ingress.Type == IngressType.whitelist)
                {
                    Logging.Log("ingress:" + ingress.Host + ":" + ingress.Application + ":inactive", Logging.LogLevel.Warn);
                    Action action = new Action(ingress.Application, isRoot: ingress.Root);
                    actionTargets[ingress.Host].Add(action);
                    if (!actions.ContainsKey(ingress.Host))
                    {
                        actions.Add(ingress.Host, -1);
                    }
                    if (actionExistingTargets.ContainsKey(ingress.Host))
                    {
                        actionExistingTargets[ingress.Host] = new List<string>();
                    }
                    if (!actionExistingTargets[ingress.Host].Contains(ingress.Application))
                    {
                        actionExistingTargets[ingress.Host].Add(ingress.Application);
                    }
                }
                else
                {
                    Logging.Log("ingress:" + ingress.Host + ":" + ingress.Application + ":ignore", Logging.LogLevel.Debug);
                }
            }

        }

        public static Dictionary<string, List<Action>> ProcessNewTenant(
            List<string> applications,
            List<string> tenants,
            ref Dictionary<string, int> actions,
            Dictionary<string, List<Action>> actionTargets
        )
        {
            Logging.Log("Process new tenants...", Logging.LogLevel.Debug);
            int newTenantCount = 0;
            foreach (string tenant in tenants)
            {
                if (!actions.ContainsKey(tenant))
                {
                    Console.WriteLine(" + " + tenant);
                    actions.Add(tenant, 1);
                    List<Action> newApplications = new List<Action>();
                    foreach (string application in applications)
                    {
                        var action = new Action(application);
                        var actionRoot = new Action(application, isRoot: true);
                        newApplications.Add(action);
                        newApplications.Add(actionRoot);
                    }
                    actionTargets.Add(tenant, newApplications);
                    newTenantCount++;
                }
            }
            if (newTenantCount == 0) Logging.Log("0 New tenants", Logging.LogLevel.Info);
            return actionTargets;
        }
    }
}
