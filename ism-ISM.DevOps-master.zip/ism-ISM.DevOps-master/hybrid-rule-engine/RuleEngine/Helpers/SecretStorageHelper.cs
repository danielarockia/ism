﻿using Azure;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using RuleEngine.Controllers;
using RuleEngine.Interfaces;
using ServiceManager.SimpleStorageStrategy.SecretStorage;
using KeyVaultSecret = ServiceManager.SimpleStorageStrategy.SecretStorage.KeyVaultSecret;
using static RuleEngine.Controllers.Logging;

namespace RuleEngine.Helpers
{
    public class SecretStorageHelper : ISimpleSecretStorageStrategy
    {
        private static readonly ISettings _settings = new Settings();
        private readonly SecretClient _client;

        public SecretStorageHelper()
        {
            string tenantId = _settings.Load("AZURE_TENANT_ID");
            string clientId = _settings.Load("AZURE_CLIENT_ID");
            string clientSecret = _settings.Load("AZURE_CLIENT_SECRET");

            if (_settings.Load("mode") == "Debug")
            {
                Log("Setting Azure Environment Variables from Config File", LogLevel.Debug);
                Environment.SetEnvironmentVariable("AZURE_TENANT_ID", tenantId);
                Environment.SetEnvironmentVariable("AZURE_CLIENT_ID", clientId);
                Environment.SetEnvironmentVariable("AZURE_CLIENT_SECRET", clientSecret);
            }

            if (!string.IsNullOrEmpty(tenantId) && !string.IsNullOrEmpty(clientId) && !string.IsNullOrEmpty(clientSecret))
            {
                string uri = _settings.Load("SecretStorageUri");
                _client = new SecretClient(new Uri(uri), new DefaultAzureCredential(new DefaultAzureCredentialOptions
                {
                    ExcludeSharedTokenCacheCredential = true
                }));
            }
        }

        public async Task<KeyVaultSecret> GetSecretAsync(string secretName, CancellationToken cancellationToken)
        {
            if (_client != null)
            {
                Response<Azure.Security.KeyVault.Secrets.KeyVaultSecret> response = await _client.GetSecretAsync(secretName, null, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
                if (response != null)
                {
                    string text = response.Value?.Value;
                    if (text != null)
                    {
                        return new KeyVaultSecret
                        {
                            Value = text,
                            Error = false
                        };
                    }
                }
            }

            return new KeyVaultSecret
            {
                Value = string.Empty,
                Error = true
            };
        }

        public Task<T> GetSecretExAsync<T>(string secretName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetSecretAsync(string secretName, string secretValue, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetSecretExAsync<T>(string secretName, T secretValue, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        Task<ServiceManager.SimpleStorageStrategy.SecretStorage.KeyVaultSecret> ISimpleSecretStorageStrategy.GetSecretAsync(string secretName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
