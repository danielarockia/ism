import logging
import json
import azure.functions as func
import os, sys

from kubernetes import client, config
from kubernetes.client.rest import ApiException
from kubernetes.client.api import core_v1_api
# from kubernetes.stream import stream
# from pymongo.message import update

dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, dir_path)
os.chdir(dir_path)

import helpers.auth as auth
import helpers.kube as kube
import helpers.file_handling as file_handler
import helpers.driver as driver
import global_vars
from services.collect import collectData
from services.collect_az import collectAzData, getTrackInfo, runPipeline
from services.get import getLogs, getPods, getDeployments, getServices, getPipelines, getTracked, getWorkflow
from services.update import updateTracked, updateWorkflow

config.load_kube_config(auth.CONFIG_FILE)

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    global_vars.v1 = client.CoreV1Api()
    global_vars.core_v1 = core_v1_api.CoreV1Api()

    def notImplemented():
        return func.HttpResponse (
            json.dumps({
                'module': module,
                'status': 'Not Implemented'
            }),
            status_code=200
         )

    def collect():
        return func.HttpResponse (
            json.dumps(collectData()),
            status_code=200
        )
    
    def secret(namespace, application):
        data = driver.secret(namespace, application, global_vars.v1)
        data = json.dumps(data)
        return func.HttpResponse (
            data,
            status_code=200
        )
    
    def cluster():
        node_list = global_vars.core_v1.list_node()
        # file = open('D:\dashboard-logs.txt', 'w')
        # file.write(str(nodes))
        # file.close()
        data = []
        for node in node_list.items:
            data.append(node.metadata.labels)
        return func.HttpResponse (
            json.dumps(data),
            status_code=200
        )

    def update_az():
        return func.HttpResponse (
            json.dumps(collectAzData()),
            status_code=200
        )

    def debug():
        path = os.path.dirname(os.path.realpath(__file__))
        os.chdir(path)
        return func.HttpResponse (
            json.dumps(os.getcwd()),
            status_code=200
        )

    routes = {
        'update'        :   collect,
        'logs'          :   getLogs,
        'envvars'       :   notImplemented,
        'pods'          :   getPods,
        'deployments'   :   getDeployments,
        'services'      :   getServices,
        'cluster'       :   notImplemented,
        'dashboard'     :   notImplemented,
        'secret'        :   secret,
        'cluster'       :   cluster,
        'updateAz'      :   update_az,
        'pipelines'     :   getPipelines,
        'updateTracked' :   updateTracked,
        'tracked'       :   getTracked,
        'trackInfo'     :   getTrackInfo,
        'updateWorkflow':   updateWorkflow,
        'workflow'      :   getWorkflow,
        'run'           :   runPipeline
    }

    parameters = {
        'logs'          :   ['application'],
        'secret'        :   ['namespace', 'application'],
        'updateTracked' :   ['body'],
        'trackInfo'     :   ['pipelineId'],
        'updateWorkflow':   ['body'],
        'run'           :   ['id']
    }
    
    module = req.route_params.get('module')
    body = req.get_body()
    parameter = []
    if module in parameters:
        for key in parameters[module]:
            if key!='body':
                parameter.append(req.params.get(key))
            else:
                parameter.append(body)
    if module in routes:
        return routes[module](*parameter)
    else:
        return func.HttpResponse (
            status_code=400
        )

    # if not name:
    #     try:
    #         req_body = req.get_json()
    #     except ValueError:
    #         pass
    #     else:
    #         name = req_body.get('module')

    # if name:
    #     return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    # else:
    #     return func.HttpResponse(
    #          "ISM Log Backend is working!",
    #          status_code=200
    #     )
