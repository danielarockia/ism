ngx.req.read_body();
local body = ngx.req.get_body_data();
-- local body = ngx.var.request_body;

local regex = '<ns1:ClientAuthenticationKey>(.*)</ns1:ClientAuthenticationKey>';
local method = ngx.var.request_method;
-- ngx.log(ngx.ERR, 'The following errors are DEBUG logs: [' .. method);

local clientAuthenticationKey = 'default';
if (body ~= nil) then
    local bodySize = '[' .. string.len(body) .. '] ';
    -- ngx.log(ngx.ERR, bodySize .. 'Body Length = ' .. string.len(body));
    -- ngx.log(ngx.ERR, bodySize .. 'Found Valid Body');
    clientAuthenticationKey = body:match(regex);
    -- ngx.log(ngx.ERR, bodySize .. 'Match: [' .. clientAuthenticationKey .. ']');
    if (clientAuthenticationKey ~= nil) then
        clientAuthenticationKey = string.gsub(clientAuthenticationKey, '^%s*(.-)%s*$', '%1')
    end
    -- ngx.log(ngx.ERR, bodySize .. 'Final Key: [' .. clientAuthenticationKey .. ']');
-- else
--     ngx.log(ngx.ERR, 'Body not found.');
end

ngx.var.clientauthenticationkey = clientAuthenticationKey;