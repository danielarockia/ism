import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SideNavService } from '../../services/side-nav.service';

@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.scss']
})
export class TopNavComponent implements OnInit {

  constructor(
    public sideNavService: SideNavService,
    private router: Router
  ) { }

  showDropDown = false;

  toggleDropDown(): void {
    this.showDropDown = !this.showDropDown;
    // console.log(this.showDropDown);
  }

  ngOnInit(): void {
  }

}
