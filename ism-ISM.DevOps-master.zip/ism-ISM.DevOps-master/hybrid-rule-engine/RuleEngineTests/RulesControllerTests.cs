using NUnit.Framework;
using RuleEngine.Controllers;

namespace RuleEngineTests
{
    public class RulesControllerTests
    {
        private Mocks.Settings Settings { get; set; }

        [SetUp]
        public void Setup()
        {
            Settings = new Mocks.Settings();
        }

        [Test]
        public void TestIMNoTenants()
        {
            RulesController rulesController = new RulesController(RulesController.RuleType.IM, Settings);
            Dictionary<string, string> tenantEncryptedKeys = new Dictionary<string, string>();
            rulesController.AddTenants(tenantEncryptedKeys);
            rulesController.Publish();

            Assert.IsTrue(File.Exists(rulesController._configFile));
            string[] lines = File.ReadAllLines(rulesController._configFile);
            Assert.That(lines.Length, Is.EqualTo(3));
            Assert.That(lines[0], Is.EqualTo("map $http_clientauthenticationkey $imclientlandscape {"));
            Assert.That(lines[1], Is.EqualTo($"\tdefault\t\"{Settings.Load("host_im_alternate")}\";"));
            Assert.That(lines[2], Is.EqualTo("}"));
        }

        [Test]
        public void TestIntegrationNoTenants()
        {
            RulesController rulesController = new RulesController(RulesController.RuleType.Integration, Settings);
            Dictionary<string, string> tenantEncryptedKeys = new Dictionary<string, string>();
            rulesController.AddTenants(tenantEncryptedKeys);
            rulesController.Publish();

            Assert.IsTrue(File.Exists(rulesController._configFile));
            string[] lines = File.ReadAllLines(rulesController._configFile);
            Assert.That(lines.Length, Is.EqualTo(3));
            Assert.That(lines[0], Is.EqualTo("map $integrationtenant $integrationlandscape {"));
            Assert.That(lines[1], Is.EqualTo($"\tdefault\t\"{Settings.Load("host_integration_alternate")}\";"));
            Assert.That(lines[2], Is.EqualTo("}"));
        }

        [Test]
        public void TestIMWithTenants()
        {
            Dictionary<string, string> tenants = CentralConfigController.GetLiveTenants(Settings, out int _);
            Dictionary<string, string> encryptedKeys = EncryptionController.EncryptTenantKeys(tenants);
            RulesController rulesController = new RulesController(RulesController.RuleType.IM, Settings);
            rulesController.AddTenants(encryptedKeys);
            rulesController.Publish();

            Assert.IsTrue(File.Exists(rulesController._configFile));
            string[] lines = File.ReadAllLines(rulesController._configFile);
            Assert.That(lines.Length, Is.EqualTo(3 + encryptedKeys.Count));
            Assert.That(lines[0], Is.EqualTo("map $http_clientauthenticationkey $imclientlandscape {"));
            Assert.That(lines[lines.Length - 1], Is.EqualTo("}"));
            for (int i = 1; i < lines.Length - 1; i++)
            {
                if (lines[i].Contains("\tdefault"))
                {
                    Assert.That(lines[i], Is.EqualTo($"\tdefault\t\"{Settings.Load("host_im_alternate")}\";"));
                }
                else
                {
                    string ip = lines[i].Split('\t')[2].Replace("\"", "").Replace(";", "");
                    Assert.That(ip, Is.EqualTo(Settings.Load("AGENTTASKWEBSERVICE_SERVICE_HOST")));
                }
            }
        }

        [Test]
        public void TestIntegrationWithTenants()
        {
            Dictionary<string, string> tenants = CentralConfigController.GetLiveTenants(Settings, out int _);
            Dictionary<string, string> encryptedKeys = EncryptionController.EncryptTenantKeys(tenants);
            RulesController rulesController = new RulesController(RulesController.RuleType.Integration, Settings);
            rulesController.AddTenants(encryptedKeys);
            rulesController.Publish();

            Assert.IsTrue(File.Exists(rulesController._configFile));
            string[] lines = File.ReadAllLines(rulesController._configFile);
            Assert.That(lines.Length, Is.EqualTo(3 + encryptedKeys.Count));
            Assert.That(lines[0], Is.EqualTo("map $integrationtenant $integrationlandscape {"));
            Assert.That(lines[lines.Length - 1], Is.EqualTo("}"));
            for (int i = 1; i < lines.Length - 1; i++)
            {
                if (lines[i].Contains("\tdefault"))
                {
                    Assert.That(lines[i], Is.EqualTo($"\tdefault\t\"{Settings.Load("host_integration_alternate")}\";"));
                }
                else
                {
                    string ip = lines[i].Split('\t')[2].Replace("\"", "").Replace(";", "");
                    Assert.That(ip, Is.EqualTo(Settings.Load("INBOUNDWEBSERVICE_SERVICE_HOST")));
                }
            }
        }

        [Test]
        public void TestCentralConfigRetryCall()
        {
            Settings.SettingsKeys["centralconfig_uri"] = "123.123.123.123";
            int retryCount = 0;
            CentralConfigController.GetLiveTenants(Settings, out retryCount);
            Assert.That(retryCount, Is.Not.EqualTo(0));
            Settings.SettingsKeys.Clear();
            CentralConfigController.GetLiveTenants(Settings, out retryCount);
            Assert.That(retryCount, Is.EqualTo(0));
        }

        [Test]
        public void TestJsonParserHelperValidJson()
        {
            string validJson =
                File.ReadAllText(
                    $"{Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)}\\TestingPayloads\\ValidPayload.json");
            var result = RuleEngine.Helpers.JSONParserHelper.Parse(validJson);
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Count, Is.EqualTo(2));
        }

        [Test]
        public void TestJsonParserHelperNonActiveTenant()
        {
            string validJson =
                File.ReadAllText(
                    $"{Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)}\\TestingPayloads\\DisabledTenantPayload.json");
            var result = RuleEngine.Helpers.JSONParserHelper.Parse(validJson);
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void TestJsonParseHelperInvalidPayload()
        {
            string validJson =
                File.ReadAllText(
                    $"{Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)}\\TestingPayloads\\InvalidPayload.json");
            var result = RuleEngine.Helpers.JSONParserHelper.Parse(validJson);
            Assert.That(result.Count, Is.EqualTo(0));
        }

        [Test]
        public void TestEncryptionController()
        {
            Dictionary<string, string> tenants = new Dictionary<string, string>();
            tenants.Add("1", "test1");
            tenants.Add("2", "test2");
            tenants.Add("3", "test3");
            var encryptionKeys = EncryptionController.EncryptTenantKeys(tenants);
            Assert.That(encryptionKeys.Count, Is.EqualTo(tenants.Count));
        }
    }
}