import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDrawer } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { SideNavService } from '../../services/side-nav.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit, AfterViewInit {

  showFiller = false;
  isExpanded = false;
  auth = true;

  @ViewChild('drawer')
  public drawer!: MatDrawer;

  constructor(
    public sideNavService: SideNavService,
    private router: Router
  ) { }


  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    this.sideNavService.setDrawer(this.drawer);
  }

}
