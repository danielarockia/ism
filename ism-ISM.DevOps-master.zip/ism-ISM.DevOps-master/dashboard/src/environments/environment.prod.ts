export const environment = {
  production: true,
  url : 'https://ism-container.azurewebsites.net/api/'
};
