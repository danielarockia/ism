import argparse, sys

import cache_manifest
import daemonset
import cache_monitor
import time

parser=argparse.ArgumentParser()
parser.add_argument('--name', help='Project Name', required=True)
parser.add_argument('--image', help='Image Tag', required=True)
parser.add_argument('--registry', help='Container Registry', required=True)
parser.add_argument('--secret', help='ACR Pull Secret', required=True)
args=parser.parse_args()

print('Generating Cache Manifest', flush=True)
manifest = cache_manifest.generate(args.name, args.image, args.registry, args.secret)
cache_manifest.save(manifest)

print('Creating DaemonSet', flush=True)
daemonset.create()
time.sleep(1)

print('Caching Images', flush=True)
cache_monitor.watch(args.name, args.image)