﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using ConfigurationManager.Globals;

namespace ConfigurationManager.Helpers
{
    class BlobStorageHelper
    {
        static string localPath = "./data/";
        static string fileName = "settings_" + Guid.NewGuid().ToString() + ".json";
        string localFilePath = Path.Combine(localPath, fileName);
        private BlobServiceClient _client;

        public void init()
        {
            string connectionString = Settings.Load("AZURE_STORAGE_CONNECTION_STRING");
            _client = new BlobServiceClient(connectionString);
        }

        public void getContainers()
        {
            Console.WriteLine("Listing Blobs Containers...");
            foreach (BlobContainerItem container in _client.GetBlobContainers())
            {
                Console.WriteLine("\t" + container.Name);
            }
        }

        public string downloadFile()
        {
            string container = Settings.Load("Container_Name");
            string blob_key = Settings.Load("Blob_Key");

            string downloadFilePath = localFilePath.Replace(".json", "DOWNLOADED.json");
            System.IO.Directory.CreateDirectory(localPath);

            BlobContainerClient containerClient = _client.GetBlobContainerClient(container);
            BlobClient blobClient = containerClient.GetBlobClient(blob_key);

            Console.WriteLine("\nDownloading blob to\n\t{0}\n", downloadFilePath);
            blobClient.DownloadTo(downloadFilePath);
            return downloadFilePath;
        }
    }
}