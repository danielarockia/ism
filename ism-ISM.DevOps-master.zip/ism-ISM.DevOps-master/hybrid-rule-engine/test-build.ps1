dotnet publish ./RuleEngine/RuleEngine.csproj -c release -o ./LoadBalancer/ruleengine/RuleEngine -r linux-x64 --self-contained
# docker rmi ruleengine
docker build -f LoadBalancer/Dockerfile.local -t ruleengine ./LoadBalancer
# docker rm -f rule-image

docker run `
--name rule-image `
-p 8080:80 `
-e "AGENTTASKWEBSERVICE_SERVICE_HOST=52.255.163.124" `
-e "INBOUNDWEBSERVICE_SERVICE_HOST=52.255.163.124" `
-e "WEBSURVEY_SERVICE_HOST=52.255.163.124" `
-e "DNSSERVICEUDP_SERVICE_HOST=8.8.8.8" `
-e "host_im_alternate=4.246.217.112" `
-e "host_integration_alternate=4.246.217.112" `
-e "host_survey_alternate=4.246.217.112" `
-e "cname_im_alternate=imclient-ldz-devprod.ivanticlouddev.com" `
-e "cname_integration_alternate=integration-ldz-devprod.ivanticlouddev.com" `
-e "cname_survey_alternate=survey-ldz-devprod.ivanticlouddev.com" `
ruleengine