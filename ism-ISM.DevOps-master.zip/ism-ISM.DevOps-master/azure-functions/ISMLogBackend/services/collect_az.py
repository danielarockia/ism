from datetime import datetime
from dateutil import parser

import os
import json
import sys

from kubernetes import client, config
from kubernetes.client.rest import ApiException
from kubernetes.client.api import core_v1_api
from kubernetes.stream import stream
from pymongo import database
import requests

import helpers.auth as auth
import helpers.kube as kube
import helpers.file_handling as file_handler
import helpers.driver as driver
import azure.functions as func

import global_vars as globals
from database.get import filterOne
from database.insert import configure

def getData(url):
    response = requests.get(
        url,
        headers={'Content-Type': 'application/json-patch+json'},
        auth=('', token))
    return response.json()

token ="yvhiruvudw2hotpfrzrzawhazxslorywdd2xb66pjhj2ihsbrmtq"
url = "https://dev.azure.com/ivanti/ISM/_apis/pipelines?api-version=6.0-preview.1"

def collectAzData():
    landscape   =   globals.LANDSCAPE
    res = True
    
    pipelines = getData(url)
    filtered_pipelines = [{'pipeline_id':k['id'], 'name':k['name'], 'root':k['folder'].split('\\')[-1]} for k in pipelines['value'] if k['folder'].startswith('\\#DotNetCore.AppDomains.Pipeline')]
    res = res and configure(globals.TABLE_PIPELINES, 'landscape', landscape, {'pipelines': filtered_pipelines})

    return({
        'updated'       :   res
    })

def getTrackInfo(id):
    landscape   =   globals.LANDSCAPE
    data = getData('https://dev.azure.com/Ivanti/ISM/_apis/build/latest/'+id+'?api-version=6.0-preview.1')
    res = {
        'id': data['id'],
        'buildNumber': data['buildNumber'],
        'branch': data['sourceBranch']
    }
    return func.HttpResponse (
        json.dumps(res) if data else json.dumps({}),
        status_code=200
    )

def runPipeline(id):
    response = requests.post(
        "https://dev.azure.com/Ivanti/ISM/_apis/pipelines/"+id+"/runs?api-version=6.0-preview.1",
        data = json.dumps({"stagesToSkip":[],"resources":{"repositories":{"self":{"refName":"refs/heads/master"}}},"variables":{}}),
        headers={'Content-Type': 'application/json'},
        auth=('', token))
    data = response.json()
    res = {
        'id': data['id'],
        'buildNumber': data['name'],
    }
    return func.HttpResponse (
        json.dumps(res) if data else json.dumps({}),
        status_code=200
    )