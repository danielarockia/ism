﻿using RuleEngine.Controllers;
using static RuleEngine.Controllers.Logging;

namespace RuleEngine
{
    class Program
    {
        private static void Main(string[] args)
        {
            try
            {
                Settings settings = new Settings();

                Dictionary<string, string> tenants = CentralConfigController.GetLiveTenants(settings, out int _);
                Dictionary<string, string> encryptedKeys = EncryptionController.EncryptTenantKeys(tenants);

                //RulesController DNSConfig = new RulesController(RulesController.RuleType.DNS, settings);
                //DNSConfig.Publish();

                RulesController integrationRules = new RulesController(RulesController.RuleType.Integration, settings);
                integrationRules.AddTenants(encryptedKeys);
                integrationRules.Publish();

                RulesController imRules = new RulesController(RulesController.RuleType.IM, settings);
                imRules.AddTenants(encryptedKeys);
                imRules.Publish();

                RulesController surveyRules = new RulesController(RulesController.RuleType.Survey, settings);
                surveyRules.AddTenants(encryptedKeys);
                surveyRules.Publish();

                if (settings.Load("mode") == "Debug")
                {
                    Log("Press Enter to close", LogLevel.Debug);
                    var _ = Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Log($"Exception building routing config files: {ex.Message} {ex.StackTrace}", LogLevel.Error);
            }
        }
    }
}