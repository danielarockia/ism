import { LoaderService } from './../../../services/controls/loader.service';
import { Component, OnInit } from '@angular/core';
import { LogsService } from 'src/app/services/apis/logs.service';

@Component({
  selector: 'app-deployments',
  templateUrl: './deployments.component.html',
  styleUrls: ['./deployments.component.scss']
})
export class DeploymentsComponent implements OnInit {

  constructor(
    public api: LogsService,
    public loader: LoaderService
  ) { }

  ngOnInit(): void {
    this.get_deployments();
  }

  deployments: any;
  DATA: any[] = [];
  namespaces = []

  displayedColumns: string[] = ['position', 'name', 'os', 'status'];

  get_deployments() {
    this.loader.show();
    this.api.getDeployments().subscribe(
      (data: any) => {
        this.deployments = data;
        this.show_deployment(this.get_namespaces()[0]);
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  show_deployment(namespace: string) {
    let keys = Object.keys(this.deployments[namespace]);
    this.DATA = [];
    for(let i=0; i<keys.length; i++){
      let row: any = this.deployments[namespace][keys[i]];
      row['name'] = keys[i];
      row['position']  = i+1;
      this.DATA.push(row);
    }
  }

  get_namespaces() {
    let namespaces = Object.keys(this.deployments);
    return namespaces;
  }

  onChange(namespace: any) {
    this.show_deployment(namespace)
  }

}
