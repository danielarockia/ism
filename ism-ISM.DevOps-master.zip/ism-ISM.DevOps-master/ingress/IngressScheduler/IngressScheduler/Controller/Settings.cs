﻿using IngressScheduler.Interfaces;
using System;
using System.Configuration;

namespace IngressScheduler.Controller
{
    public class Settings : ISettings
    {
        public string Load(string key)
        {
            string value = Environment.GetEnvironmentVariable(key);
            if (value == null)
            {
                value = ConfigurationManager.AppSettings[key];
            }
            return value;
        }
    }
}
