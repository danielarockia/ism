﻿docker stop $(docker ps -a -q --filter="name=rule-image")
docker rm $(docker ps -a -q --filter="name=rule-image")