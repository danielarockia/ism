﻿using IngressScheduler.Controller;
using IngressScheduler.Interfaces;
using IngressScheduler.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace IngressScheduler.Helpers
{
    public class IngressStaticRule
    {
        [JsonProperty("name")]
        public string name { get; set; }
        [JsonProperty("path")]
        public string path { get; set; }
        [JsonProperty("namespace")]
        public string appNamespace { get; set; }
        [JsonProperty("host")]
        public string host { get; set; }
        [JsonProperty("landscape")]
        public string landscape { get; set; }
        [JsonProperty("secret")]
        public string secret { get; set; }
    }
    public class IngressStaticRuleData
    {
        [JsonProperty("Data")]
        public IngressStaticRule Data { get; set; }
    }
    public static class LoadData
    {
        public static List<IngressStaticRuleData> Invoke(ISettings settings)
        {
            int attempt = 1;
            Logging.Log("Loading Static Configurations from Dashboard...", Logging.LogLevel.Info);

            while (attempt <= 3)
            {
                Logging.Log("Attempt " + attempt.ToString() + " ...", Logging.LogLevel.Debug);
                try
                {
                    HttpWebRequest webRequest = CreateWebRequest(settings);
                    IAsyncResult asyncResult = webRequest.BeginGetResponse(null, null);
                    asyncResult.AsyncWaitHandle.WaitOne();
                    string result;
                    using (WebResponse webResponse = webRequest.EndGetResponse(asyncResult))
                    {
                        using (StreamReader rd = new StreamReader(webResponse.GetResponseStream()))
                        {
                            result = rd.ReadToEnd();
                        }
                    }

                    var data = JsonConvert.DeserializeObject<List<IngressStaticRuleData>>(result);
                    Logging.Log(data.Count + " Static Rules Loaded from Server", Logging.LogLevel.Info);

                    foreach (IngressStaticRuleData ruleData in data)
                    {
                        IngressStaticRule rule = ruleData.Data;
                        Applications.staticApplicationList[rule.name] = new ApplicationDetails(
                            path: rule.path,
                            app_namespace: rule.appNamespace,
                            host: rule.host + "." + rule.secret + ".com"
                        );
                    }

                    return data;
                }
                catch (Exception ex)
                {
                    Logging.Log("Attempt " + attempt.ToString() + " Failed...", Logging.LogLevel.Error);
                    Logging.Log(ex.Message, Logging.LogLevel.Warn);
                    attempt++;
                }
            }
            if (attempt > 3)
            {
                SafetyProtection.Lock();
            }
            return null;
        }

        private static HttpWebRequest CreateWebRequest(ISettings settings)
        {
            string dashboardURI = settings.Load("dashboard_uri");
            string datacenter = settings.Load("datacenter");
            datacenter = datacenter.ToUpper();
            Logging.Log("Datacenter : " + datacenter, Logging.LogLevel.Info);
            string url = dashboardURI + "/api/internal/object/IngressStaticRules?filter=Data.landscape.matches(\"" + datacenter + "\")";
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Headers.Add("api-key", settings.Load("dashboard_api_key"));
            webRequest.Headers.Add("role", "internal");
            webRequest.ContentType = "application/json";
            webRequest.Accept = "application/json";
            webRequest.Method = "GET";
            return webRequest;
        }
    }
}
