import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FormService {

  // pod resources manager server url
  url: string = "http://ism-pod-resource-server.ivanticlouddev.com/";

  constructor(private http: HttpClient) { }

  httpOptions = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  };

  getForm(landscape: string, application: string): any {
    const data = this.http.get(
      this.url + 'resources/'+landscape+'/'+application,
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }

  updateForm(landscape: string, application: string, form_data: any): any {
    console.log(form_data);
    const data = this.http.post(
      this.url + 'resources/'+landscape+'/'+application,
      JSON.stringify(form_data),
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }

  getSchema1(schema: string): any {
    const data = this.http.get(
      this.url + 'schema/'+schema,
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }

  updateSchema(schema: string, form_data: any): any {
    console.log(form_data);
    const data = this.http.post(
      this.url + 'schema/'+schema,
      JSON.stringify(form_data),
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }


  getLandscapes(): any {
    const data = this.http.get(
      this.url + 'list',
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }

  getSchema(): any {
    const data = this.http.get(
      this.url + 'schemas/'+ 'terraform' +'/table',
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }

  getTable(landscape: string): any {
    const data = this.http.get(
      this.url + 'resources/'+landscape+'/table',
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }

  import(landscape: string, form_data: any): any {
    const data = this.http.post(
      this.url + 'import/'+landscape,
      JSON.stringify(form_data),
      {
        headers: new HttpHeaders(this.httpOptions)
      }
    );
    return data;
  }
}
