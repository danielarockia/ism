import azure.functions as func
from database.get import filterOne, cappedLatestMultiFiltered
import global_vars as globals
import json

def get_table(table):
    data = filterOne(table, 'landscape', globals.LANDSCAPE)
    return func.HttpResponse (
        json.dumps(data['data']),
        status_code=200
    )

def getLogs(application):
    return func.HttpResponse (
        json.dumps(cappedLatestMultiFiltered(
            globals.TABLE_LOGS,
            {
                # 'landscape'     :   globals.LANDSCAPE,
                'deployment'    :   application
            })
        ),
        status_code=200
    )

def getPipelines():
    data = filterOne(globals.TABLE_PIPELINES, 'landscape', globals.LANDSCAPE)
    return func.HttpResponse (
        json.dumps(data['pipelines']),
        status_code=200
    )

def getPipelines():
    data = filterOne(globals.TABLE_PIPELINES, 'landscape', globals.LANDSCAPE)
    return func.HttpResponse (
        json.dumps(data['pipelines']),
        status_code=200
    )

def getPods():
    return get_table(globals.TABLE_PODS)

def getDeployments():
    return get_table(globals.TABLE_DEPLOYMENTS)

def getServices():
    return get_table(globals.TABLE_SERVICES)

def getTracked():
    data = filterOne(globals.TABLE_TRACKED, 'landscape', globals.LANDSCAPE)
    return func.HttpResponse (
        json.dumps(data['data']) if data else json.dumps({}),
        status_code=200
    )

def getWorkflow():
    data = filterOne(globals.TABLE_WORKFLOW, 'landscape', globals.LANDSCAPE)
    return func.HttpResponse (
        json.dumps(data['data']) if data else json.dumps({}),
        status_code=200
    )

