﻿using RuleEngine.Helpers;
using RuleEngine.Interfaces;

namespace RuleEngine.Controllers
{
    public class RulesController
    {
        public enum RuleType
        {
            IM,
            Integration,
            Survey,
            DNS,
            None
        }
        private RuleType _ruleType;
        public string _configFile { get; private set; }
        private string _configHeader = "map ";      
        private Dictionary<string, string> _configBody;

        private string _host_im;
        private string _host_integration;
        private string _host_survey;
        private string _host_im_alternate;
        private string _host_integration_alternate;
        private string _host_survey_alternate;
        private string _cname_im_alternate;
        private string _cname_integration_alternate;
        private string _cname_survey_alternate;
        private string _dns_server;

        private ISettings Settings { get; set; }

        public RulesController(RuleType ruleType, ISettings settings)
        {
            Settings = settings;

            _ruleType = ruleType;
            _configBody = new Dictionary<string, string>();

            _host_im = Settings.Load("AGENTTASKWEBSERVICE_SERVICE_HOST");
            _host_integration = Settings.Load("INBOUNDWEBSERVICE_SERVICE_HOST");
            _host_survey = Settings.Load("WEBSURVEY_SERVICE_HOST");

            _host_im_alternate = Settings.Load("host_im_alternate");
            _host_integration_alternate = Settings.Load("host_integration_alternate");
            _host_survey_alternate = Settings.Load("host_survey_alternate");
            
            _cname_im_alternate = Settings.Load("cname_im_alternate");
            _cname_integration_alternate = Settings.Load("cname_integration_alternate");
            _cname_survey_alternate = Settings.Load("cname_survey_alternate");

            _dns_server = Settings.Load("DNSSERVICEUDP_SERVICE_HOST");

            if (_ruleType == RuleType.Integration)
            {
                _configHeader += "$integrationtenant $integrationlandscape";
                _configBody["default"] = _cname_integration_alternate;
                _configFile = "rules.integration.conf";
                CNameHelper.Create(_cname_integration_alternate, _host_integration_alternate, settings);
            }
            else if (_ruleType == RuleType.IM)
            {
                _configHeader += "$clientauthenticationkey $imclientlandscape";
                _configBody["default"] = _host_im_alternate;
                _configFile = "rules.im.conf";
                CNameHelper.Create(_cname_im_alternate, _host_im_alternate, settings);
            }
            else if (_ruleType == RuleType.Survey)
            {
                _configHeader += "$surveytenant $surveylandscape";
                _configBody["default"] = _host_survey_alternate;
                _configFile = "rules.survey.conf";
                CNameHelper.Create(_cname_survey_alternate, _host_survey_alternate, settings);
            }
            else if (_ruleType == RuleType.DNS)
            {
                _configHeader += "\"\" $dnsserver";
                _configBody["default"] = _dns_server;
                _configFile = "rules.dns.conf";
            }
        }

        public void AddTenants(Dictionary<string, string> tenants)
        {
            foreach (var tenant in tenants)
            {
                if (_ruleType == RuleType.Integration)
                {
                    _configBody[tenant.Key] = _host_integration;
                }
                else if (_ruleType == RuleType.IM)
                {
                    _configBody[tenant.Value] = _host_im;
                }
                else if (_ruleType == RuleType.Survey)
                {
                    _configBody[tenant.Key] = _host_survey;
                }
            }
        }

        public void Publish()
        {
            String output = "";
            output += _configHeader;
            output += " {\n";
            foreach (var rule in _configBody)
            {
                output += "\t" + rule.Key + "\t\"" + rule.Value + "\";\n";
            }
            output += "}";           
            File.WriteAllText(_configFile, output);
            Logging.Log("Published : " + _configFile, Logging.LogLevel.Info);
        }

        public void PublishVariable()
        {
            String output = "";
            output += _configHeader;
            foreach (var rule in _configBody)
            {
                output += "$" + rule.Key + " = \"" + rule.Value + "\";\n";
            }
            File.WriteAllText(_configFile, output);
            Logging.Log("Published : " + _configFile, Logging.LogLevel.Info);
        }
    }
}
