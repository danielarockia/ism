﻿namespace Logging
{
    internal class LogLevel
    {
    }
}