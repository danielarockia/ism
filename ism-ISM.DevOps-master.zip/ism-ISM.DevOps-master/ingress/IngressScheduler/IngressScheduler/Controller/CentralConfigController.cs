﻿using IngressScheduler.Helpers;
using IngressScheduler.Interfaces;
using System;
using System.Collections.Generic;

namespace IngressScheduler.Controller
{
    public static class CentralConfigController
    {
        public static List<String> GetActiveTenants(ISettings settings)
        {
            string url = settings.Load("centralconfig_uri");
            string method = "GetActiveTenants";
            List<string> activeTenants = new List<string>();
            try
            {
                String soapResponse = Soap.invoke(url, method);
                if (soapResponse == null) SafetyProtection.Lock();
                activeTenants = ActiveTenantXMLParser.Parse(soapResponse);
            }
            catch(Exception ex)
            {
                SafetyProtection.Lock();
            }

            Console.WriteLine(activeTenants.Count.ToString() + " Host Entries Found in ConfigDB.");

            return activeTenants;
        }
    }
}
