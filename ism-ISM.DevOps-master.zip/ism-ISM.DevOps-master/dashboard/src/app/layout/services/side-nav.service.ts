import { Injectable } from '@angular/core';
import { MatDrawer } from '@angular/material/sidenav';

@Injectable({
  providedIn: 'root'
})
export class SideNavService {
  public drawer!: MatDrawer;
  public isExpanded = false;

  constructor() { }

  setDrawer(drawer: MatDrawer): void {
      this.drawer = drawer;
  }

  toggleSideNav(): void {
    // this.drawer.toggle();
    this.isExpanded = !this.isExpanded;
  }
}
