import { Component, OnInit } from '@angular/core';
import { LogsService } from 'src/app/services/apis/logs.service';
import { LoaderService } from 'src/app/services/controls/loader.service';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-deployment',
  templateUrl: './deployment.component.html',
  styleUrls: ['./deployment.component.scss']
})
export class DeploymentComponent implements OnInit {

  constructor(
    public api: LogsService,
    public loader: LoaderService
  ) { }

  subscription: Subscription = new Subscription();

  ngOnInit(): void {
    this.get_tracked();
    this.get_workflow();
    this.subscription = interval(1000).subscribe(val => this.get_status());
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  workflow = new Array();
  tracked = new Map();
  tracked_keys = new Array();
  ready = false;
  trackCache = new Map();
  checkList: any;

  status = 'Queued';
  checks = ['Trigger', 'Build', 'Push', 'Deploy']

  current = 0;
  memory = Array();

  stages = [
    'CI', 'DEVPRD'
  ]

  get_tracked() {
    this.loader.show();
    this.api.getTracked().subscribe(
      (data: any) => {
        console.log(data)
        Object.keys(data).forEach((element: any) => {
          this.tracked_keys.push(Number(element));
          this.tracked.set(Number(element), data[element]);
        });
        this.ready = true;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_workflow() {
    this.loader.show();
    this.api.getWorkflow().subscribe(
      (data: any) => {
        this.workflow = data;
        data.forEach(() => {
          this.memory.push(new Map());
        });
        this.ready = true;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_status() {
    console.log('status');
    var id = this.tracked_keys[this.current];
    // this.api.check(id).subscribe(
    //   (data: any) => {
    //     console.log(data)
    //     this.status = 'Queued';
    //   }
    // );
    this.status = 'Success';
    if(this.status=='Success' && this.current<=this.workflow.length){
      this.currentCheck += 1;
      if(this.currentCheck >= this.checks.length){
        this.currentCheck = 0;
        this.current += 1;
      }
    }
    this.memory[this.current].set(this.checks[this.currentCheck], this.status);
    if(this.status=='Success'){
      this.status = 'In Progress';
    }
  }

  currentCheck = 0

}

