using IngressScheduler.Controller;
using IngressScheduler.Helpers;
using IngressScheduler.Interfaces;
using IngressScheduler.Models;
using k8s;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using System.Collections.Generic;
using System.Linq;

namespace IngressScheduler.Tests
{
    [TestClass]
    public class FunctionalTests : TestBase
    {
        [TestMethod]
        public void Test_GetActiveTenants_Success()
        {
            //ISettings settings = new TestSettings();
            var tenants = CentralConfigController.GetActiveTenants(settings);
            Assert.IsTrue(tenants?.Any());
        }

        [TestMethod]
        [Ignore]
        public void Test_GetKubernetesClientConfigFromConfigFile()
        {
            string kubeConfigFilePath = settings.Load("configFilePath") + settings.Load("kubeconfigfile");
            var config = KubernetesClientConfiguration.BuildConfigFromConfigFile(kubeConfigFilePath);
            Assert.IsNotNull(config);

            IKubernetes client = new Kubernetes(config);
            Assert.IsNotNull(client);
        }
        
        [TestMethod]
        public void Test_Production_KubeConnection()
        {
            IKubernetes client = KubeConnection.Connect(settings, Modes.Production);
            Assert.IsNotNull(client);
        }

        [TestMethod]
        public void Test_GetKubernetesClientConfigFromDefaultConfig()
        {
            var config = KubernetesClientConfiguration.BuildDefaultConfig();
            Assert.IsNotNull(config);

            IKubernetes client = new Kubernetes(config);
            Assert.IsNotNull(client);
        }

        [TestMethod]
        public void Test_LoadData()
        {
            var staticRules = LoadData.Invoke(settings);
            Assert.IsTrue(staticRules.Any());
            Assert.AreEqual(4, staticRules.Where(s => s.Data.landscape == settings.Load("datacenter")).Count());
        }

        [TestMethod]
        public void Test_GetIngress()
        {
            var config = KubernetesClientConfiguration.BuildDefaultConfig();
            Assert.IsNotNull(config);

            IKubernetes client = new Kubernetes(config);

            var ingressList = KubernetesIngress.GetIngress(client, null);
            Assert.IsNotNull(ingressList);
        }

        [TestMethod]
        public void Test_ProcessIngress()
        {
            var config = KubernetesClientConfiguration.BuildDefaultConfig();
            Assert.IsNotNull(config);

            IKubernetes client = new Kubernetes(config);

            var tenants = new List<string>
            {
                "test-tenant1.ism.com",
                "test-tenant2.ism.com",
                "test-tenant3.ism.com"
            };

            ProcessController.ProcessIngress(settings, client, tenants);

            var ingressList = KubernetesIngress.GetIngress(client, null);
            Assert.AreEqual(18, ingressList.Where(i => i.Host == "test-tenant1.ism.com").Count());

            tenants = new List<string>
            {
                "test-tenant1.ism.com",
                "test-tenant2.ism.com",
                "test-tenant4.ism.com"
            };

            ProcessController.ProcessIngress(settings, client, tenants);

            ingressList = KubernetesIngress.GetIngress(client, null);
            Assert.AreEqual(18, ingressList.Where(i => i.Host == "test-tenant2.ism.com").Count());
            Assert.AreEqual(0, ingressList.Where(i => i.Host == "test-tenant3.ism.com").Count());
            Assert.AreEqual(18, ingressList.Where(i => i.Host == "test-tenant4.ism.com").Count());
        }
    }
}