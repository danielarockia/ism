import { Component, OnInit } from '@angular/core';
import { NgxFlowChatOptions, NgxFlowChatData } from 'ngx-flowchart'
import { LogsService } from 'src/app/services/apis/logs.service';
import { LoaderService } from 'src/app/services/controls/loader.service';

@Component({
  selector: 'app-release',
  templateUrl: './release.component.html',
  styleUrls: ['./release.component.scss']
})
export class ReleaseComponent implements OnInit {

  constructor(
    public api: LogsService,
    public loader: LoaderService
  ) {}

  ngOnInit(): void {
    // this.get_pipelines();
    this.get_tracked();
  }

  pipelines: any = new Map();
  pages: any = Array();
  tracked: any = new Map();
  tracked_keys: any = new Array();
  dirty = false;

  get_pipelines() {
    this.loader.show();
    this.api.getPipelines().subscribe(
      (data: any) => {
        data.forEach((element: any) => {
          var root = element["root"];
          var name = element["name"];
          var id = element["pipeline_id"];
          if(!this.pipelines.has(root)){
            this.pipelines.set(root, new Array());
            this.pages.push(root);
          }
          this.pipelines.get(root).push({'name': name, 'id': id});
        });
        this.pages=this.pages.sort();
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_tracked() {
    this.loader.show();
    this.api.getTracked().subscribe(
      (data: any) => {
        console.log(data)
        Object.keys(data).forEach((element: any) => {
          console.log(element);
          console.log(data[element]);
          this.add_track(Number(element), data[element]);
        });
        this.dirty = false;
        console.log(this.tracked_keys);
        this.get_pipelines();
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  clean(name: any){
    var tokens = ['ServiceManager.', '.Core', '.CI', 'Services.', 'Service'];
    tokens.forEach(element => {
      name = name.replace(element, '');
    });
    return name;
  }

  add_track(id: any, name: any){
    if(!this.tracked.has(id)){
      this.dirty = true;
      this.tracked.set(id, name);
      this.tracked_keys.push(id);
      console.log(this.tracked_keys);
    }
  }

  remove_track(id: any){
    this.tracked.delete(id);
    var index = this.tracked_keys.indexOf(id, 0);
    if (index > -1) {
      this.tracked_keys.splice(index, 1);
    }
  }

  open(id:any){
    window.open('https://ivanti.visualstudio.com/ISM/_build?definitionId='+id, '_blank')?.focus();
  }

  save() {
    this.loader.show();
    var payload: any = {};
    this.tracked.forEach((val: string, key: string) => {
      payload[key] = val;
    });
    console.log(this.tracked);
    this.api.updateTracked(payload).subscribe(
      (data: any) => {
        console.log(data);
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

}
