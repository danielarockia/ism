﻿using IngressScheduler.Interfaces;

namespace IngressScheduler.Controller
{
    internal class SafetyProtection
    {
        public static bool deletionProtection(ISettings settings) => settings.Load("deletion_protection") == "true";
        public static bool deletionLock = false;

        public static void Lock()
        {
            deletionLock = true;
            Logging.Log("Safety Lock Enforced", Logging.LogLevel.Security);
        }

        public static void Unlock()
        {
            deletionLock = false;
        }

        public static bool CheckStatus(ISettings settings)
        {
            if (deletionProtection(settings))
            {
                if (deletionLock)
                {
                    Logging.Log("Safety Lock Detected", Logging.LogLevel.Security);
                    Logging.Log("Operation skipped", Logging.LogLevel.Warn);
                }
                return !deletionLock;
            }
            else
            {
                return true;
            }
        }
    }
}
