﻿using IngressScheduler.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace IngressScheduler.Tests
{
    internal class TestSettings : ISettings
    {
        private readonly TestContext testContext;

        public TestSettings(TestContext testContext)
        {
            this.testContext = testContext;
        }

        public string Load(string key)
        {
            if (testContext == null)
                throw new System.Exception("RunSettings file is not configured");

            if (!testContext.Properties.Contains(key))
                throw new System.Exception($"'{key}' is not present in RunSettings");

            return testContext.Properties[key].ToString();
        }
    }
}
