﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationManager.Globals
{
    public class Settings
    {
        public static String[] acceptedArguments = {
            "InputConfig",
            "OutputConfig",
            //"ConfigFile"
        };
        public static string Load(string key)
        {
            string value = Environment.GetEnvironmentVariable(key);
            if (value == null)
            {
                value = System.Configuration.ConfigurationManager.AppSettings[key];
            }
            return value;
        }
    }
}
