﻿using RuleEngine.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine.Controllers
{
    internal class SafetyProtectionController
    {
        public static bool? deletionProtection = null;        

        public static void Lock()
        {
            Logging.Log("Safety Lock Enforced", Logging.LogLevel.Security);
        }
    }
}
