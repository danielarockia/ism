import os
import json

#GEt Directory
def getRoot(namespace):
    directory = 'output/'+namespace+'/'
    return directory

# Check Files
def init(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
        os.makedirs(directory+'logs/')
        os.makedirs(directory+'error-logs/')

# Save Output
def save(directory, name, data, seralize=True):
    if(not seralize):
        file = open(directory + '/' + name + '.log', 'w')
        output = data
        file.write(output)
        file.close()
    else:
        file = open(directory + '/' + name + '.json', 'w')
        output = json.dumps(data, indent=4, sort_keys=True)
        file.write(output)
        file.close()