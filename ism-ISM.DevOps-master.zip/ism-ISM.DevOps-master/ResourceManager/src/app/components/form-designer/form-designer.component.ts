import { Component, OnInit, ViewChild } from '@angular/core';
import { CodeModel } from '@ngstack/code-editor';
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { Subject } from 'rxjs';
import { FormService } from 'src/app/services/api/form.service';
import { LoaderService } from 'src/app/services/controls/loader.service';

@Component({
  selector: 'app-form-designer',
  templateUrl: './form-designer.component.html',
  styleUrls: ['./form-designer.component.scss']
})
export class FormDesignerComponent implements OnInit {

  constructor(
    private api: FormService,
    public loader: LoaderService
  ) {}

  ngOnInit(): void {
    this.get_form();
  }

  public refresh = true;
  public data: any = {}
  public code: any = JSON.stringify(this.data);
  public form: any = JSON.parse(this.code);
  dirty = false;

  schema = 'terraform';

  editorOptions: any = {
    theme: 'vs-dark',
    language: 'json'
  };

  update(val: any) {
    this.data = val;
    this.code= JSON.stringify(this.data);
    this.form = JSON.parse(this.code);
    this.beautify();
    this.dirty = true;
  }

  beautify() {
    this.code = JSON.stringify(this.data, null, 2);
  }

  parse_form() {
    this.refresh = false;

    this.data = JSON.parse(this.code);
    this.form = JSON.parse(this.code);
    console.log('====================================');
    console.log(this.code);
    console.log('====================================');
    console.log("Parsed");

    // this.refresh = true;

  }

  get_form() {
    this.loader.show();
    this.api.getSchema1(this.schema).subscribe(
      (data: any) => {
        this.update(data);
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  save_form() {
    this.loader.show();
    this.api.updateSchema(this.schema, this.data).subscribe(
      (data: any) => {
        this.data = data;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

}
