#!/bin/sh
echo -e "\n" >> /etc/dnsmasq.conf
echo -e "address=/$IM_URI/$IM_BACKEND_IP" >> /etc/dnsmasq.conf
echo -e "address=/$INTEGRATION_URI/$INTEGRATION_BACKEND_IP" >> /etc/dnsmasq.conf
echo -e "address=/$SURVEY_URI/$SURVEY_BACKEND_IP" >> /etc/dnsmasq.conf
webproc --config /etc/dnsmasq.conf --port 80 -- dnsmasq --no-daemon