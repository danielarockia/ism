﻿using RuleEngine.Helpers;
using RuleEngine.Interfaces;
using static RuleEngine.Controllers.Logging;

namespace RuleEngine.Controllers
{
    public static class CentralConfigController
    {
        public static Dictionary<string, string> GetLiveTenants(ISettings Settings, out int retryCounter)
        {
            retryCounter = 0;
            string url = Settings.Load("centralconfig_uri");
            int maxRetryCount = Convert.ToInt32(Settings.Load("centralconfig_max_retry_count"));
            if (maxRetryCount == 0)
                maxRetryCount = 1;
            int retryTimeout = Convert.ToInt32(Settings.Load("centralconfig_retry_timeout_ms"));
            string method = "GetActiveTenants";
            string apiKey = ApiKeyController.GetApiKey(ApiKeyController.centralConfigApiKeyName);
            Dictionary<string, string> activeTenants = new Dictionary<string, string>();
            while (maxRetryCount > 0)
            {
                try
                {
                    HttpClient client = new HttpClient();
                    string restEndpoint = $"{url}/{method}";

                    var requestMessage = new HttpRequestMessage(HttpMethod.Get, restEndpoint);
                    requestMessage.Headers.Add("ApiKey", apiKey);

                    var restResponse = client.Send(requestMessage);
                    string jsonResponse = restResponse.Content.ReadAsStringAsync().Result;

                    if (string.IsNullOrEmpty(jsonResponse) || restResponse.StatusCode != System.Net.HttpStatusCode.OK)
                        SafetyProtectionController.Lock();

                    activeTenants = JSONParserHelper.Parse(jsonResponse);
                    break;
                }
                catch (Exception ex)
                {
                    Log($"Error retriving active tenants: {ex.Message} {ex.StackTrace}", LogLevel.Error);
                    SafetyProtectionController.Lock();
                }
                maxRetryCount--;
                retryCounter++;
                Thread.Sleep(retryTimeout);
            }

            Console.WriteLine(activeTenants.Count.ToString() + " Host Entries Found in ConfigDB.");

            return activeTenants;
        }
    }
}
