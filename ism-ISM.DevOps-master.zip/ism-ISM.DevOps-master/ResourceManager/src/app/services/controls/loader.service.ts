import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  public enable = false;

  constructor() { }

  show(): void {
    this.enable = true;
  }

  hide(): void {
    this.enable = false;
  }
}
