﻿using IngressScheduler.Helpers;
using IngressScheduler.Models;
using k8s;
using k8s.Models;
using System;
using System.Collections.Generic;

namespace IngressScheduler.Controller
{
    public static class KubernetesIngress
    {
        public static List<Ingress> GetIngress(IKubernetes client, List<string> namespaceFilter = null)
        {
            if (namespaceFilter == null)
            {
                namespaceFilter = new List<string>();
            }
            List<Ingress> ingressList = new List<Ingress>();
            var namespaces = client.ListNamespace();
            int whitelist_count = 0;
            int static_count = 0;
            int root_count = 0;
            foreach (V1Namespace _namespace in namespaces.Items)
            {
                if (namespaceFilter.Count == 0 || namespaceFilter.Contains(_namespace.Metadata.Name))
                {
                    var list = client.ListNamespacedIngress(_namespace.Metadata.Name);
                    foreach (var item in list.Items)
                    {
                        Ingress ingress = new Ingress();
                        ingress.Name = item.Metadata.Name;
                        ingress.Path = item.Spec.Rules[0].Http.Paths[0].Path;
                        ingress.Host = item.Spec.Rules[0].Host;
                        if (ingress.Name.Contains(IngressCompose.base_key))
                        {
                            ingress.Root = true;
                            root_count++;
                        }
                        if (ingress.Name.StartsWith(IngressCompose.prefix))
                        {
                            if (ingress.Name.EndsWith(StaticRules.suffix))
                            {
                                ingress.Type = IngressType._static;
                                ingress.Application = item.Metadata.Labels["App"];
                                static_count++;
                            }
                            else
                            {
                                ingress.Type = IngressType.whitelist;
                                ingress.Application = item.Metadata.Labels["App"];
                                whitelist_count++;
                            }
                        }
                        ingressList.Add(ingress);
                    }
                }
            }
            Logging.Log(ingressList.Count.ToString() + " Ingress Entries Found", Logging.LogLevel.Info);
            Logging.Log(root_count.ToString() + " Root Entries", Logging.LogLevel.Info);
            Logging.Log(whitelist_count.ToString() + " Whitelist Entries", Logging.LogLevel.Info);
            Logging.Log(static_count.ToString() + " Static Entries", Logging.LogLevel.Info);
            return ingressList;
        }

        public static bool CreateIngress(IKubernetes client, string host, string appName, string appNamespace, string suffix = "", bool root = false)
        {
            V1Ingress ingress = IngressCompose.compose(host, appName, appNamespace, suffix, root);
            try
            {
                V1Ingress response = client.CreateNamespacedIngress(ingress, ingress.Metadata.NamespaceProperty);
                //Console.WriteLine(response.Metadata.Name + " - " + response.Status.LoadBalancer.Ingress[0].Ip);
                return true;
            }
            catch (Exception ex)
            {
                Logging.Log("Ingress Creation failed:" + ex.Message, Logging.LogLevel.Error);
                return false;
            }
        }

        public static bool UpdateIngress(IKubernetes client, string host, string appName, string appNamespace, string suffix = "", bool root = false)
        {
            V1Ingress ingress = IngressCompose.compose(host, appName, appNamespace, suffix, root);
            try
            {
                V1Ingress response = client.ReplaceNamespacedIngress(ingress, ingress.Metadata.Name, ingress.Metadata.NamespaceProperty);
                //Console.WriteLine(response.Metadata.Name + " - " + response.Status.LoadBalancer.Ingress[0].Ip);
                return true;
            }
            catch (Exception ex)
            {
                Logging.Log("Ingress Updation failed:" + ex.Message, Logging.LogLevel.Error);
                return false;
            }

        }

        public static bool DeleteIngress(IKubernetes client, string host, string appName, string appNamespace, string suffix = "", bool root = false)
        {
            V1Ingress ingress = IngressCompose.compose(host, appName, appNamespace, suffix, root);
            try
            {
                V1Status response = client.DeleteNamespacedIngress(ingress.Metadata.Name, ingress.Metadata.NamespaceProperty);
                //Console.WriteLine(response.Status);
                return true;
            }
            catch (Exception ex)
            {
                Logging.Log("Ingress Deletion failed:" + ex.Message, Logging.LogLevel.Error);
                return false;
            }
        }
    }
}
