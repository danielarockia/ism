﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationManager.Helpers
{
    public class JsonHelper
    {
        public dynamic LoadData(string configurationFile)
        {
            try
            {
                using (StreamReader r = new StreamReader(configurationFile))
                {
                    string json = r.ReadToEnd();
                    var array = JsonConvert.DeserializeObject(json);
                    return array;
                }
            }
            catch
            {
                string message = "Unable to read JSON Configurations";
                Console.WriteLine(message);
                throw new Exception(message);
            }
        }
    }
}
