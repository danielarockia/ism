﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine.Controllers
{
    public static class Logging
    {
        private static List<ConsoleColor> colors = new List<ConsoleColor>()
        {
            ConsoleColor.Cyan,
            ConsoleColor.White,
            ConsoleColor.Yellow,
            ConsoleColor.Red,
            ConsoleColor.Magenta,
            ConsoleColor.Green,
            ConsoleColor.Gray,
            ConsoleColor.Blue
        };

        private static string Level(LogLevel loglevel)
        {
            switch ((int)loglevel)
            {
                case -1:
                    return "FATAL";
                case 0:
                    return "DEBUG";
                case 1:
                    return "INFO";
                case 2:
                    return "WARN";
                case 3:
                    return "ERROR";
                case 4:
                    return "FATAL";
                case 5:
                    return "SECURITY";
                default:
                    return "INFO";
            }
        }

        public enum LogLevel
        {
            Debug,
            Info,
            Warn,
            Error,
            Fatal,
            Security
        };

        public static void Log(string s, LogLevel loglevel)
        {
            DateTime datetime = DateTime.Now;
            string timestamp = String.Format("{0:u}", datetime);
            string spacing = timestamp + " ";
            
            if(loglevel >= 0)
            {
                spacing += "|" + Level(loglevel) + "\t|";
                Console.ForegroundColor = colors[(int)loglevel % colors.Count()];
                //for (int i = 0; i < (int)loglevel; i++)
                //{
                //    spacing += String.Concat(Enumerable.Repeat(" ", 4));
                //}
                //spacing += " - ";
            }

            if ((int)loglevel == -1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
                
            Console.WriteLine(spacing + s);
            //Console.Clear();
            Console.ResetColor();

        }
    }
}
