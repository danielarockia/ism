﻿using IngressScheduler.Controller;
using IngressScheduler.Interfaces;
using k8s;
using k8s.Util.Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IngressScheduler.Tests
{
    [TestClass]
    public class TestBase
    {
       
        public static ISettings settings { get; set; }

        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext testContext)
        {
            settings = new TestSettings(testContext);
        }

        public TestBase()
        {
             
        }

        [AssemblyCleanup]
        public static void Cleanup()
        {
            var config = KubernetesClientConfiguration.BuildDefaultConfig();
            IKubernetes client = new Kubernetes(config);

            foreach(var @namespace in client.ListNamespace().Items)
            {
                client.DeleteCollectionNamespacedIngress(@namespace.Metadata.Name);
            }
        }
    }
}
