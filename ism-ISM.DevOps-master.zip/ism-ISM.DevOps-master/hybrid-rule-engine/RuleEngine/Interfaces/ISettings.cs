﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine.Interfaces
{
    public interface ISettings
    {
        public string Load(string key);
    }
}
