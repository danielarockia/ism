namespaces  =   ['ism', 'workflow', 'email', 'analyst', 'redis']
LANDSCAPE   =   "NVZ-CI"
INTERVAL    =   20

v1          =   None
core_v1     =   None
CONFIG_FILE =   'kubectl.conf'

MONGODB_CONNECTION_STRING   =   "mongodb://localhost:27017/?readPreference=primary&directConnection=true&ssl=false"
MONGODB_DATABASE            =   "ISMDashboard"

# MONGODB_CONNECTION_STRING   =   "mongodb://admin:xXkU2vqoBMGfEKldmxTNhuH6@cluster0-shard-00-00.c9xhi.mongodb.net:27017,cluster0-shard-00-01.c9xhi.mongodb.net:27017,cluster0-shard-00-02.c9xhi.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-2hy8pu-shard-0&authSource=admin&retryWrites=true&w=majority"

TABLE_LOGS          =   "logs"
TABLE_LANDSCAPE     =   "landscape"
TABLE_PODS          =   "pods"
TABLE_DEPLOYMENTS   =   "deployments"
TABLE_SERVICES      =   "services"
TABLE_PIPELINES     =   "pipelines"
TABLE_TRACKED       =   "tracked"
TABLE_WORKFLOW      =   "workflow"