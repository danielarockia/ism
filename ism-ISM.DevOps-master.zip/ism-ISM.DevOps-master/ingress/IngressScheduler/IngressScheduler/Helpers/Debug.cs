﻿using IngressScheduler.Controller;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Action = IngressScheduler.Models.Action;

namespace IngressScheduler.Helpers
{
    internal class Debug
    {
        public static void printTargets(Dictionary<string, List<string>> actionTargets)
        {
            foreach (string host in actionTargets.Keys.ToList())
            {
                string line = "";
                Logging.Log(host, Logging.LogLevel.Info);
                foreach (string application in actionTargets[host])
                {
                    line += application + ", ";
                }
                Logging.Log(line, Logging.LogLevel.Debug);
            }
            if (actionTargets.Count == 0)
            {
                Logging.Log("0 Targets", Logging.LogLevel.Info);
            }
        }

        public static void printTargets(Dictionary<string, List<Action>> actionTargets)
        {
            foreach (string host in actionTargets.Keys.ToList())
            {
                string line = "";
                Logging.Log(host, Logging.LogLevel.Info);
                foreach (Action action in actionTargets[host])
                {
                    line += action.Application + (action.Root == true ? "[base]" : "") + ", ";
                }
                Logging.Log(line, Logging.LogLevel.Debug);
            }
            if (actionTargets.Count == 0)
            {
                Logging.Log("0 Targets", Logging.LogLevel.Info);
            }
        }

        public static void Pause()
        {
            Task.Delay(60 * 1000).Wait();
        }
    }
}
