import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormService } from 'src/app/services/api/form.service';
import { LoaderService } from 'src/app/services/controls/loader.service';

@Component({
  selector: 'app-import',
  templateUrl: './import.component.html',
  styleUrls: ['./import.component.scss']
})
export class ImportComponent implements OnInit {

  constructor(
    private api: FormService,
    public loader: LoaderService,
    private _snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<ImportComponent>,
  ) { }

  ngOnInit(): void {
  }

  landscape: string = "";
  rawtext: string = "";

  openSnackBar(message: string) {
    this._snackBar.open(
      message,
      'Dismiss',
      {
        horizontalPosition: 'center',
        verticalPosition: 'top',
      });
  }

  submit() {
    this.loader.show();
    this.api.import(this.landscape, this.rawtext).subscribe(
      (data: any) => {
        const message = data;
        this.openSnackBar(message);
        this.dialogRef.close();
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
        this.openSnackBar('Changes not saved.');
      }
    );
  }


}
