MANIFEST_FILE='cache_manifest.yaml'

CACHE_IMAGE_TEMPLATE = 'templates/cacheimages.template'
DAEMONSET_TEMPLATE = 'templates/daemonset.template'

DEBUG = False
DEBUG_LANDSCAPE = 'NVZ-CI'