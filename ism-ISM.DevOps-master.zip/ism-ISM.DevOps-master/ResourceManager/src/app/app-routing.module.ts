import { ExplorerComponent } from './components/explorer/explorer.component';
import { FormDesignerComponent } from './components/form-designer/form-designer.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DynamicFormComponent } from './components/dynamic-form/dynamic-form.component';


const routes: Routes = [
  { path: '', component: ExplorerComponent },
  { path: 'new', component: FormDesignerComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
