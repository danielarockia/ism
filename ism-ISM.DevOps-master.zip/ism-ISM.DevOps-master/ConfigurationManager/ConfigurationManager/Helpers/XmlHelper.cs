﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace ConfigurationManager.Helpers
{
    public class XmlHelper
    {
        static string Pretty(string xml)
        {
            var stringBuilder = new StringBuilder();

            var element = XElement.Parse(xml);

            var settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            settings.Indent = true;
            settings.NewLineOnAttributes = true;

            using (var xmlWriter = XmlWriter.Create(stringBuilder, settings))
            {
                element.Save(xmlWriter);
            }

            return stringBuilder.ToString();
        }

        public static XmlDocument UpdateProperty(XmlDocument _doc, Models.Property data)
        {
            string _path = data.path;
            string _selector = data.selector;
            string _selectorValue = data.selectorValue;
            string _value = data.value;

            XmlNodeList aNodes = _doc.SelectNodes(_path);
            foreach (XmlNode aNode in aNodes)
            {
                XmlAttribute idAttribute = aNode.Attributes[_selector];
                if (idAttribute != null)
                {
                    string currentValue = idAttribute.Value;
                    if (currentValue == _selectorValue)
                    {
                        aNode.InnerXml = "<value>" + _value + "</value>";
                    }
                }
            }
            return _doc;
        }

        public static XmlDocument updateAttribute(XmlDocument _doc, Models.Attribute data)
        {
            string _path = data.path;
            string _selector = data.selector;
            string _selectorValue = data.selectorValue;
            string _attribute = data.attribute;
            string _attributeValue = data.value;

            XmlNodeList aNodes = _doc.SelectNodes(_path);
            foreach (XmlNode aNode in aNodes)
            {
                XmlAttribute selectedAttribute = aNode.Attributes[_selector];
                if (selectedAttribute != null)
                {
                    string currentValue = selectedAttribute.Value;
                    if (currentValue == _selectorValue)
                    {
                        XmlAttribute attribute = aNode.Attributes[_attribute];
                        if (attribute != null)
                        {
                            attribute.Value = _attributeValue;
                            Console.WriteLine(Pretty(aNode.OuterXml));
                        }
                    }
                }
            }
            return _doc;
        }
    }
}
