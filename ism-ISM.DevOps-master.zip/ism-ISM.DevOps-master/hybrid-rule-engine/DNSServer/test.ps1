docker run `
	--name dnsmasq `
	-d `
	-p 53:53/udp `
	-p 5380:80 `
	--log-opt "max-size=100m" `
	-e "HTTP_USER=admin" `
	-e "HTTP_PASS=manage" `
	-e "IM_URI=imclient-ldz-devprod.ivanticlouddev.com" `
	-e "INTEGRATION_URI=integration-ldz-devprod.ivanticlouddev.com" `
	-e "SURVEY_URI=survey-ldz-devprod.ivanticlouddev.com" `
	-e "IM_BACKEND_IP=4.246.217.112" `
	-e "INTEGRATION_BACKEND_IP=4.246.217.112" `
	-e "SURVEY_IP=4.246.217.112" `
	--restart always `
	dnsmasq