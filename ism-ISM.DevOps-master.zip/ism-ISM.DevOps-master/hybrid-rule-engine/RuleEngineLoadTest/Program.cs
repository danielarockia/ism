﻿using RuleEngine.Controllers;
using System.Diagnostics;
using System.Management.Automation;
using System.Text;

namespace RuleEngineLoadTest
{
    class Program
    {
        private static void Main(string[] args)
        {
            Settings settings = new Settings();
            Dictionary<string, string> tenants = CentralConfigController.GetLiveTenants(settings, out int _);
            Dictionary<string, string> encryptedKeys = EncryptionController.EncryptTenantKeys(tenants);

            Console.WriteLine("--------------------------------------------------------------------------------");
            TestConfFileIsValidIM(settings, encryptedKeys);
            Console.WriteLine("--------------------------------------------------------------------------------");
            TestConfFileIsValidIntegration(settings, tenants);
            Console.WriteLine("--------------------------------------------------------------------------------");
            TestRuleEngineLatency(settings, encryptedKeys);
            Console.WriteLine("--------------------------------------------------------------------------------");
            RunInParallel(settings, encryptedKeys, 8);
            Console.WriteLine("--------------------------------------------------------------------------------");                       

            Console.WriteLine("Done");
        }

        #region Test Docker Conf Files

        private static void TestConfFileIsValidIM(Settings settings, Dictionary<string, string> encryptedKeys)
        {            
            string getIMConfigScript = File.ReadAllText(settings.Load("docker_read_im_config_script_location"));
            using PowerShell ps = PowerShell.Create();
            ps.AddScript(getIMConfigScript);
            var output = ps.Invoke();
            StringBuilder sb = new StringBuilder();
            foreach (var x in output)
            {
                sb.AppendLine(x.BaseObject.ToString());
            }
            string[] lines = SplitIntoLines(sb.ToString().Trim());
            bool invalid = false;
            if (lines.Length != 3 + encryptedKeys.Count)
                invalid = true;
            if (lines[0] != "map $http_clientauthenticationkey $imclientlandscape {")
                invalid = true;
            if (lines[lines.Length - 1] != "}")
                invalid = true;                        
            for (int i = 1; i < lines.Length - 1; i++)
            {
                if (lines[i].Contains("\tdefault"))
                {
                    string expectedLine = $"\tdefault\t\"{settings.Load("host_im_alternate")}\";";
                    if (lines[i] != expectedLine)
                        invalid = true;                    
                }
                else
                {
                    string ip = lines[i].Split('\t')[2].Replace("\"", "").Replace(";", "");
                    if (ip != settings.Load("AGENTTASKWEBSERVICE_SERVICE_HOST"))
                        invalid = true;
                }
            }
            if(invalid ==false)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("IM Configuration is valid");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("IM Configuration is invalid");                
            }
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void TestConfFileIsValidIntegration(Settings settings, Dictionary<string, string> tenants)
        {
            string getIntegrationConfigScript = File.ReadAllText(settings.Load("docker_read_integration_config_script_location"));
            using PowerShell ps = PowerShell.Create();
            ps.AddScript(getIntegrationConfigScript);
            var output = ps.Invoke();
            StringBuilder sb = new StringBuilder();
            foreach (var x in output)
            {
                sb.AppendLine(x.BaseObject.ToString());
            }
            string[] lines = SplitIntoLines(sb.ToString().Trim());
            bool invalid = false;
            if (lines.Length != 3 + tenants.Count)
                invalid = true;
            if (lines[0] != "map $integrationtenant $integrationlandscape {")
                invalid = true;
            if (lines[lines.Length - 1] != "}")
                invalid = true;            
            for (int i = 1; i < lines.Length - 1; i++)
            {
                if (lines[i].Contains("\tdefault"))
                {                    
                    if (lines[i] != $"\tdefault\t\"{settings.Load("host_integration_alternate")}\";")
                        invalid = true;
                }
                else
                {
                    string ip = lines[i].Split('\t')[2].Replace("\"", "").Replace(";", "");
                    if (ip != settings.Load("INBOUNDWEBSERVICE_SERVICE_HOST"))
                        invalid = true;
                }
            }
            if (invalid == false)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Integration Configuration is valid");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Integration Configuration is invalid");                
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        private static string[] SplitIntoLines(string fileContent) => fileContent.Split(
            new string[] { "\r\n", "\r", "\n" },
            StringSplitOptions.None
        );


        #endregion

        #region Network Calls Tests

        private static void TestRuleEngineLatency(Settings settings, Dictionary<string, string> encryptionKeys, int nrOfTests = 10)
        {
            string[] keys = encryptionKeys.Values.ToArray();
            Random rand = new Random();

            string url1 = settings.Load("rule_engine_latency_test_endpoint1");
            string url2 = settings.Load("rule_engine_latency_test_endpoint2");

            long avgMsDiff = 0;
            for (int i = 0; i < nrOfTests; i++)
            {
                long url1Ms = MakeCallAndTrackMs(url1, rand.Next() % 2 == 0 ? string.Empty : keys[rand.Next(0, keys.Length)]);
                long url2Ms = MakeCallAndTrackMs(url2, rand.Next() % 2 == 0 ? string.Empty : keys[rand.Next(0, keys.Length)]);
                long diff = Math.Abs(url1Ms - url2Ms);
                if (url1Ms > url2Ms)
                {
                    Console.WriteLine($"{url1} took more time than {url2}: {diff}ms");
                }
                else
                {
                    Console.WriteLine($"{url2} took more time than {url1}: {diff}ms");
                }
                avgMsDiff += diff;
            }
            avgMsDiff = avgMsDiff / nrOfTests;
            Console.WriteLine($"Average difference between endpoints is: {avgMsDiff}ms");
        }
        private static long MakeCallAndTrackMs(string url, string key)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            try
            {
                using HttpClient client = new HttpClient();
                HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Get, url);
                if (!string.IsNullOrEmpty(key))
                    requestMessage.Headers.Add("clientauthenticationkey", key);
                var result = client.Send(requestMessage);
                if (result.StatusCode != System.Net.HttpStatusCode.OK)
                    throw new Exception($"Error sending request to {url}");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"Exception occured: {ex.Message}");
                Console.ForegroundColor = ConsoleColor.White;
            }
            sw.Stop();
            return sw.ElapsedMilliseconds;
        }
        private static void RunInParallel(Settings settings, Dictionary<string, string> encryptionKeys, int instances = 4)
        {
            List<int> ints = new List<int>();
            Parallel.For(0, instances, new ParallelOptions { MaxDegreeOfParallelism = instances }, count =>
            {
                ints.Add(MakeSyncCallsTest(settings, encryptionKeys, 1));
            });
            Console.WriteLine($"Total successfull requests count: {ints.Sum()}");
        }
        private static int MakeSyncCallsTest(Settings settings, Dictionary<string, string> encryptionKeys, int iterations = 10)
        {
            int cnt = 0;
            for (int i = 1; i <= iterations; i++)
            {
                int count = 0;
                int failedCount = 0;
                Random rand = new Random();
                string[] keys = encryptionKeys.Values.ToArray();
                Stopwatch sw = new Stopwatch();
                sw.Start();
                while (true)
                {
                    if (MakeCall(settings, rand.Next() % 2 == 0 ? string.Empty : keys[rand.Next(0, keys.Length)]))
                    {
                        count++;
                    }
                    else
                    {
                        failedCount++;
                    }
                    if (sw.ElapsedMilliseconds > 1000 * 60)
                    {
                        break;
                    }
                }
                sw.Stop();
                Console.WriteLine($"Load test {i} finished.\n{count} successful requests in 1 min \n{failedCount} unsuccessful requests in 1 min");
                Console.WriteLine("-------------------------");
                cnt += count;
            }
            return cnt;
        }
        private static bool MakeCall(Settings settings, string key)
        {
            try
            {
                Random rand = new Random();
                using HttpClient client = new HttpClient();
                HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Get, rand.Next() % 2 == 0 ? settings.Load("rule_engine_latency_test_endpoint1") : settings.Load("rule_engine_latency_test_endpoint2"));
                if (!string.IsNullOrEmpty(key))
                    requestMessage.Headers.Add("clientauthenticationkey", key);
                var result = client.Send(requestMessage);
                return result.StatusCode == System.Net.HttpStatusCode.OK;
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion
    }
}