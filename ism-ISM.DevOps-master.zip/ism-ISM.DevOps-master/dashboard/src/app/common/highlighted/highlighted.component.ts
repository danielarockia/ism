import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-highlighted',
  templateUrl: './highlighted.component.html',
  styleUrls: ['./highlighted.component.scss']
})
export class HighlightedComponent implements OnInit {
  @Input() content: any;
  interpolate = {
    language: 'language interpolated'
  };
  language = 'html';

  constructor() { }

  ngOnInit(): void {
  }

}
