import { environment } from './../../../../environments/environment.prod';
import { Component, OnInit } from '@angular/core';
import { LogsService } from 'src/app/services/apis/logs.service';
import { LoaderService } from 'src/app/services/controls/loader.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-environment',
  templateUrl: './environment.component.html',
  styleUrls: ['./environment.component.scss']
})
export class EnvironmentComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    public api: LogsService,
    public loader: LoaderService
  ) { }

  envs: any[] = [];
  envs_settings: any[] = [];
  namespace: any;
  deployment: any = '';
  view_only: any = false;
  deployments: any;
  DATA: any[] = [];
  namespaces = [];
  applications:any[] = [];
  table_ready = false;

  ngOnInit(): void {
    // var id = this.route.snapshot.paramMap.get('id');
    // console.log('==============SubModule========');
    // console.log(this.deployment);
    // if(this.deployment!=null){
    //   this.view_only = true;
    //   this.show(this.namespace, this.deployment);
    // }
    this.get_deployments();
  }

  get_deployments() {
    this.loader.show();
    this.api.getDeployments().subscribe(
      (data: any) => {
        this.deployments = data;
        console.log(this.deployments);
        this.show_deployment(this.get_namespaces()[0]);
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_env(namespace: any, application: any) {
    this.loader.show();
    this.api.getEnv(namespace, application).subscribe(
      (data: any) => {
        this.envs = [];
        this.envs_settings = []
        Object.keys(data).forEach((element, index) => {
          this.envs.push({
            'index' : index,
            'key'   : element,
            'value' : atob(data[element])
          })
          var type = 'text';
          var element2 = element.toUpperCase();
          if(element.localeCompare(element2)===0){
            type = 'password';
          }
          this.envs_settings.push({
            'type': type,
            'lock': true
          })
        });
        console.log(this.envs);
        console.log(this.envs_settings);
        this.dataSource = this.envs;
        this.table_ready = true;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  show_deployment(namespace: string) {
    this.namespace = namespace;
    let keys = Object.keys(this.deployments[namespace]);
    this.DATA = [];
    for(let i=0; i<keys.length; i++){
      let row: any = this.deployments[namespace][keys[i]];
      row['name'] = keys[i];
      row['position']  = i+1;
      this.DATA.push(row);
    }
    this.applications = keys;
  }

  get_namespaces() {
    if(this.deployment==null){
      return [];
    }
    let namespaces = Object.keys(this.deployments?this.deployments:{});
    return namespaces;
  }

  onChange(namespace: any) {
    this.show_deployment(namespace);
  }

  show(namespace: any, application: any) {
    this.get_env(namespace, application)
  }

  displayedColumns: string[] = ['key', 'value'];
  dataSource = [
    {key: 'Hint', value: 'Please Select an application.'}
  ];

  checkLock(i: number) {
    if(this.envs_settings[i].type=='password'){
      if(this.envs_settings[i].lock==true){
        return true;
      }
    }
    return false;
  }

  checkUnlock(i: number) {
    if(this.envs_settings[i].type=='text'){
      if(this.envs_settings[i].lock==false){
        return true;
      }
    }
    return false;
  }

  toggleLock(i: number) {
    if(this.envs_settings[i].lock===true){
      this.envs_settings[i].type='text'
    }
    else{
      this.envs_settings[i].type='password'
    }
    this.envs_settings[i].lock=!this.envs_settings[i].lock;
  }

}
