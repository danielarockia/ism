﻿using BetterConsoleTables;
using DataLayer.Extensions;
using LicenseServerCommon.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine.Controllers
{
    public static class EncryptionController
    {
        public static Dictionary<string, string> EncryptTenantKeys(Dictionary<string, string> tenants)
        {
            Dictionary<string, string> encryptedKeys = new Dictionary<string, string>();
            Table table = new Table("#", "Tenant", "Encrypted CA Key");
            table.Config = TableConfiguration.MySql();
            int tenantCount = 0;
            foreach (var tenant in tenants)
            {
                tenantCount++;
                string clientAuthenticationKey = tenant.Value;
                string encryptedKey = clientAuthenticationKey.Encrypt();
                encryptedKeys[tenant.Key] = encryptedKey;
                table.AddRow(tenantCount, tenant.Key, encryptedKey);
            }
            Console.WriteLine(table.ToString());
            Logging.Log("Keys Encrypted = " + tenantCount.ToString(), Logging.LogLevel.Info);
            return encryptedKeys;
        }
    }
}
