import { LogsService } from './../../../services/apis/logs.service';
import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/services/controls/loader.service';
import { BrowserModule } from '@angular/platform-browser';
import { LegendPosition, NgxChartsModule } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(
    public api: LogsService,
    public loader: LoaderService
  ) { }

  deployments: any;
  nodes: any;
  READY_G1 = false;
  READY_G2 = false;
  DATA_NAMESPACE: any[] = [];
  DATA_OS: any[] = [];
  DATA_NODES: Map<String, any> = new Map<String, any>();

  get_deployments() {
    this.loader.show();
    this.api.getDeployments().subscribe(
      (data: any) => {
        this.deployments = data;
        console.log(this.deployments);

        Object.keys(this.deployments).forEach(element => {
          this.DATA_NAMESPACE.push({
            'name'  : element,
            'value' : Object.keys(this.deployments[element]).length
          })
        });
        this.READY_G1 = true;

        var win = 0;
        var linux = 0;
        Object.keys(this.deployments).forEach(element => {
          Object.keys(this.deployments[element]).forEach(item => {
            if(this.deployments[element][item].os==='linux'){
              linux += 1;
            }
            else {
              win += 1;
            }
          })
        })
        this.DATA_OS.push({
          'name'  : 'windows',
          'value' : win
        });
        this.DATA_OS.push({
          'name'  : 'linux',
          'value' : linux
        });
        console.log(win);
        console.log(linux);
        console.log(this.DATA_OS);
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_nodes() {
    this.loader.show();
    this.api.getNodes().subscribe(
      (data: any) => {
        this.nodes = data;
        console.log(this.nodes);

        this.nodes.forEach((element: { [x: string]: any; }) => {
          var agentPool = element['agentpool'];
          if(!this.DATA_NODES.has(agentPool)){
            this.DATA_NODES.set(agentPool, new Map<string, any>());
            this.DATA_NODES.get(agentPool).set('Running Instances', 1);
            this.DATA_NODES.get(agentPool).set('Instance Type', element['node.kubernetes.io/instance-type']);
            this.DATA_NODES.get(agentPool).set('OS', element['kubernetes.io/os']);
            this.DATA_NODES.get(agentPool).set('Arch', element['kubernetes.io/arch']);
            this.DATA_NODES.get(agentPool).set('Region', element['failure-domain.beta.kubernetes.io/region']);
            this.DATA_NODES.get(agentPool).set('Instance Type', element['node.kubernetes.io/instance-type']);
            this.DATA_NODES.get(agentPool).set('Image', element['kubernetes.azure.com/node-image-version']);
          }
          else{
            var count = this.DATA_NODES.get(agentPool).get('Running Instances')
            this.DATA_NODES.get(agentPool).set('Running Instances', count+1);
          }
        });
        console.log('====================================');
        console.log(this.DATA_NODES);
        console.log(this.DATA_NODES.keys());
        console.log('====================================');
        this.READY_G2 = true;
      }
    )
  }

  // options
  view1: [number, number] = [680, 250];
  view2: [number, number] = [400, 200];
  gradient: boolean = false;
  showLegend: boolean = true;
  showLabels: boolean = true;
  isDoughnut: boolean = false;
  legendPosition = LegendPosition.Below;

  ngOnInit(): void {
    this.get_deployments();
    this.get_nodes();
  }

  getNodeIcon(os: string){
    if(os=='windows'){
      return 'https://www.freeiconspng.com/thumbs/windows-icon-png/cute-ball-windows-icon-png-16.png';
    }
    else{
      return 'https://cdn-icons-png.flaticon.com/512/888/888879.png';
    }
  }
}
