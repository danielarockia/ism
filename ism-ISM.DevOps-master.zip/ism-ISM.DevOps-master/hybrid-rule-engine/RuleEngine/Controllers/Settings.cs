﻿using RuleEngine.Interfaces;
using System.Configuration;

namespace RuleEngine.Controllers
{
    public class Settings : ISettings
    {
        public string Load(string key)
        {
            string value = Environment.GetEnvironmentVariable(key);
            if (value == null)
            {
                value = ConfigurationManager.AppSettings[key];
            }
            return value;
        }
    }
}
