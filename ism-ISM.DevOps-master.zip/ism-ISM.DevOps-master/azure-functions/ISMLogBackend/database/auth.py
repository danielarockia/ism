from pymongo import MongoClient
from ISMLogBackend import global_vars

def getDatabase():
    client = MongoClient(global_vars.MONGODB_CONNECTION_STRING, serverSelectionTimeoutMS=5000)
    db = client[global_vars.MONGODB_DATABASE]
    return db