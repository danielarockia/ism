from Crypto.Cipher import ARC2
from Crypto.Util.Padding import pad
# from Crypto.PublicKey import RC2

input = bytes([0]*16)
# key = bytes([0]*8)
# iv = b"\x01\x02\x03\x04\x05\x06\x07\x08"

encoding = 'utf8'
key = bytes("d9c8d860-bjkhzxpisetrlxcvndfsgdfgxcmv4g7", encoding)
iv = bytes("35jhb,dsjhklxhczviouy96y5hjladksnvkjh789", encoding)[:8]

res = "OLxHBfmKAM/19qEQZEsPOD2mTX4VyTxRLvFtdzhI6Nc9hIvntC/0TQ=="

print(len(iv))

cipher = ARC2.new(key, ARC2.MODE_CBC, iv=iv)

msg = cipher.encrypt(pad(input, len(iv), style='pkcs7'))
print("{} {}".format(len(msg), msg.hex()))