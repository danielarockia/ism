import { SideNavService } from './../../services/side-nav.service';
import { Component, OnInit } from '@angular/core';
import { SideCatalog } from '../../models/SideCatalog.model';
import { ActivatedRoute, Router } from '@angular/router';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'app-side-nav',
  animations: [
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(-30%)', opacity: 0}),
          animate('100ms', style({transform: 'translateX(0)', opacity: 1}))
        ]),
        // transition(':leave', [
        //   style({transform: 'translateX(0)', opacity: 1}),
        //   animate('1ms', style({transform: 'translateX(-100%)', opacity: 0}))
        // ])
      ]
    )
  ],
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {

  products = [
    new SideCatalog('Dashboard', 'assessment'),
    new SideCatalog('Pipelines', 'play_circle_filled'),
    new SideCatalog('Rollouts', 'cloud_upload'),
    new SideCatalog('Deployments', 'group_work'),
    new SideCatalog('Pods', 'donut_large'),
    new SideCatalog('Environment', 'view_stream' ),
    new SideCatalog('Logs', 'description' ),
    new SideCatalog('Settings', 'settings')
  ];
  selected = '';

  constructor(
    public sideNavService: SideNavService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.selected = this.router.url.slice(1);
    if (this.selected === '') {
      this.selected = 'Dashboard';
    }
  }

  navigate(page: string): void {
    this.router.navigate([ page ], { relativeTo: this.route });
  }
}
