$NEWBRANCH="2021.4"

$location=(pwd).Path

Get-Content .\repos.txt | ForEach-Object {
    $repo=$_
	cd ./Repos
	if((ls | grep d- | grep $repo | wc -l).Lines -gt 0)
	{
		echo " - Repo already exists"
	}
	else
	{
		echo " - Cloning Repo"
		git clone https://github.com/ivantiinc/$repo.git
	}
	
	if(!((ls | grep d- | grep $repo | wc -l).Lines -gt 0))
	{
		echo " - Repo not found"
		cd $location
		continue
	}
	cd $repo	
	$branch=(git branch --show-current)
	echo " - Repo : $repo"
	echo " - Branch : $branch"
	if($branch -ne "master")
	{
		$master_exists=(git branch --list master)
		$master_exists=$master_exists.trim()
		if($master_exists -eq "master"){
			git checkout master
			$branch=(git branch --show-current)
			echo " - Switched to master branch"
		}
		else
		{
			echo " - Branch:master not found"
		}
	}
	echo " - Pull : $branch"
	git pull
	$branch_exists=(git branch --list $NEWBRANCH)
	$branch_exists=$branch_exists.trim()
	if($branch_exists -eq $NEWBRANCH){
		git branch -D $NEWBRANCH
		echo " - Deleted branch:$NEWBRANCH"
	}
	
	echo " - Checkout $NEWBRANCH"
	git checkout -b $NEWBRANCH
	echo " - Push $NEWBRANCH"
	git push --set-upstream origin $NEWBRANCH
	echo -------------------
	cd $location
	#break
}