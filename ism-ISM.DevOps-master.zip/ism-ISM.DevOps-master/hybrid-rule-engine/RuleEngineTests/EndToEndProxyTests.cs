﻿using Newtonsoft.Json;
using NUnit.Framework;
using RuleEngine.Controllers;
using System.Data.SqlClient;
using System.Management.Automation;
using System.Net;
using System.Text;

namespace RuleEngineTests
{
    internal class EndToEndProxyTests
    {
        private Mocks.Settings Settings { get; set; }
        private string ParentDirectory { get; set; }
        private string LaunchContainerScript { get; set; }
        private string StopContainerScript { get; set; }

        [SetUp]
        public void Setup()
        {
            Settings = new Mocks.Settings();
            string assemblyLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            ParentDirectory = assemblyLocation.Remove(assemblyLocation.IndexOf("RuleEngineTests\\"));
            LaunchContainerScript = $"Set-Location -Path {ParentDirectory}" + Environment.NewLine +
                File.ReadAllText(Path.Combine(assemblyLocation, "HelperScripts\\LaunchContainer.ps1"));
            StopContainerScript = $"Set-Location -Path {ParentDirectory}" + Environment.NewLine +
                File.ReadAllText(Path.Combine(assemblyLocation, "HelperScripts\\StopContainer.ps1"));
        }

        [Test]
        public void LaunchDockerContainer()
        {
            LaunchContainer();
            Assert.IsTrue(CheckIfContainerIsRunning());
            //StopContainer();
        }

        [Test]
        public void CheckContinerConfFiles()
        {
            PrepareConfigFile(
                Settings.Load("centralconfig_uri"),
                Settings.Load("AGENTTASKWEBSERVICE_SERVICE_HOST"),
                Settings.Load("host_im_alternate"),
                Settings.Load("INBOUNDWEBSERVICE_SERVICE_HOST"),
                Settings.Load("host_integration_alternate"),
                Settings.Load("centralconfig_max_retry_count"),
                Settings.Load("centralconfig_retry_timeout_ms")
            );
            LaunchContainer();
            Assert.IsTrue(CheckIfContainerIsRunning());

            Dictionary<string, string> tenants = CentralConfigController.GetLiveTenants(Settings, out int _);

            ValidateIMConfiguration(
                GetIMConfigurationFromContainer(),
                tenants.Count,
                Settings.Load("host_im_alternate"),
                Settings.Load("AGENTTASKWEBSERVICE_SERVICE_HOST")
            );
            ValidateIntegrationConfiguration(
                GetIntegrationConfigurationFromContainer(),
                tenants.Count,
                Settings.Load("host_integration_alternate"),
                Settings.Load("INBOUNDWEBSERVICE_SERVICE_HOST")   
            );

            StopContainer();
        }

        [Test]
        public void CheckProxy()
        {
            string validProxyIp = TestContext.Parameters["valid_proxy"];
            PrepareConfigFile(
                Settings.Load("centralconfig_uri"),
                validProxyIp,
                Settings.Load("host_im_alternate"),
                validProxyIp,
                Settings.Load("host_integration_alternate"),
                Settings.Load("centralconfig_max_retry_count"),
                Settings.Load("centralconfig_retry_timeout_ms")
            );
            LaunchContainer();
            Assert.IsTrue(CheckIfContainerIsRunning());

            Dictionary<string, string> tenants = CentralConfigController.GetLiveTenants(Settings, out int _);
            Dictionary<string, string> tenantEncryptedKeys = EncryptionController.EncryptTenantKeys(tenants);

            string imConfig = GetIMConfigurationFromContainer().Trim();
            string integrationConfig = GetIntegrationConfigurationFromContainer().Trim();

            ValidateIMConfiguration(
                imConfig,
                tenants.Count,
                Settings.Load("host_im_alternate"),
                validProxyIp
            );
            ValidateIntegrationConfiguration(
                integrationConfig,
                tenants.Count,
                Settings.Load("host_integration_alternate"),
                validProxyIp
            );

            string podEndpoint = Settings.Load("pod_endpoint");

            HttpClient client = new HttpClient();
            HttpRequestMessage httpRequestMessageNoKey = new HttpRequestMessage(HttpMethod.Get, podEndpoint);
            var responseNoKey = client.Send(httpRequestMessageNoKey);
            // Request should fail as the default IP is invalid in this test case            
            Assert.That(responseNoKey.StatusCode, Is.Not.EqualTo(HttpStatusCode.OK));
            Assert.IsTrue(responseNoKey.Content.ReadAsStringAsync().Result.Contains("timeout"));

            HttpRequestMessage httpRequestMessageWithKey = new HttpRequestMessage(HttpMethod.Get, podEndpoint);
            httpRequestMessageWithKey.Headers.Add("clientauthenticationkey", tenantEncryptedKeys.First().Value);
            var responseWithKey = client.Send(httpRequestMessageWithKey);
            // Request should NOT fail as the default IP is valid in this test case
            Assert.That(responseWithKey.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(
                JsonConvert.DeserializeObject<dynamic>(responseWithKey.Content.ReadAsStringAsync().Result).hostname.ToString(),
                Is.EqualTo(validProxyIp)
            );    

            StopContainer();
        }

        [TestCase]
        public void DisabledTenantRouting()
        {
            Dictionary<string, string> tenants = CentralConfigController.GetLiveTenants(Settings, out int _);
            Dictionary<string, string> tenantEncryptedKeys = EncryptionController.EncryptTenantKeys(tenants);

            int originalTenantsCount = tenants.Count;
            string tenantToDisable = tenants.Keys.Where(x => x != "ConfigDB").First();
            string key = tenantEncryptedKeys[tenantToDisable];

            string validProxyIp = TestContext.Parameters["valid_proxy"];
            PrepareConfigFile(
                Settings.Load("centralconfig_uri"),
                validProxyIp,
                Settings.Load("host_im_alternate"),
                validProxyIp,
                Settings.Load("host_integration_alternate"),
                Settings.Load("centralconfig_max_retry_count"),
                Settings.Load("centralconfig_retry_timeout_ms")
            );
            LaunchContainer();
            Assert.IsTrue(CheckIfContainerIsRunning());

            string podEndpoint = Settings.Load("pod_endpoint");
            HttpClient client = new HttpClient();
            HttpRequestMessage httpRequestMessageWithKey = new HttpRequestMessage(HttpMethod.Get, podEndpoint);
            httpRequestMessageWithKey.Headers.Add("clientauthenticationkey", key);
            var responseWithKey = client.Send(httpRequestMessageWithKey);            
            Assert.That(responseWithKey.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(
                JsonConvert.DeserializeObject<dynamic>(responseWithKey.Content.ReadAsStringAsync().Result).hostname.ToString(),
                Is.EqualTo(validProxyIp)
            );
            StopContainer();

            using (SqlConnection connection = new SqlConnection(Settings.Load("config_db_connection_string")))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(string.Empty, connection);
                command.CommandText = "UPDATE Tenants SET Status = 'Disabled' WHERE TenantUrl = '"+tenantToDisable+"'";
                command.ExecuteNonQuery();

                tenants = CentralConfigController.GetLiveTenants(Settings, out int _);
                tenantEncryptedKeys = EncryptionController.EncryptTenantKeys(tenants);
                Assert.That(tenants.Count, Is.EqualTo(originalTenantsCount - 1));

                LaunchContainer();
                Assert.IsTrue(CheckIfContainerIsRunning());
                HttpRequestMessage httpRequestMessageWithKey_disabled = new HttpRequestMessage(HttpMethod.Get, podEndpoint);
                httpRequestMessageWithKey_disabled.Headers.Add("clientauthenticationkey", key);
                responseWithKey = client.Send(httpRequestMessageWithKey_disabled);
                Assert.That(responseWithKey.StatusCode, Is.Not.EqualTo(HttpStatusCode.OK));
                StopContainer();

                command.CommandText = "UPDATE Tenants SET Status = 'Active' WHERE TenantUrl = '" + tenantToDisable + "'";
                command.ExecuteNonQuery();
                connection.Close();

                LaunchContainer();
                Assert.IsTrue(CheckIfContainerIsRunning());
                HttpRequestMessage httpRequestMessageWithKey_reenabled = new HttpRequestMessage(HttpMethod.Get, podEndpoint);
                httpRequestMessageWithKey_reenabled.Headers.Add("clientauthenticationkey", key);
                responseWithKey = client.Send(httpRequestMessageWithKey_reenabled);
                Assert.That(responseWithKey.StatusCode, Is.EqualTo(HttpStatusCode.OK));
                StopContainer();
            }
        }

        private void ValidateIMConfiguration(string imConfig, int tenantsCount, string defaultAddress, string redirectedAddress)
        {
            string[] lines = SplitIntoLines(imConfig.Trim());
            Assert.That(lines.Length, Is.EqualTo(3 + tenantsCount));
            Assert.That(lines[0], Is.EqualTo("map $http_clientauthenticationkey $imclientlandscape {"));
            Assert.That(lines[lines.Length - 1], Is.EqualTo("}"));
            for (int i = 1; i < lines.Length - 1; i++)
            {
                if (lines[i].Contains("\tdefault"))
                {
                    Assert.That(lines[i], Is.EqualTo($"\tdefault\t\"{defaultAddress}\";"));
                }
                else
                {
                    string ip = lines[i].Split('\t')[2].Replace("\"", "").Replace(";", "");
                    Assert.That(ip, Is.EqualTo(redirectedAddress));
                }
            }
        }

        private void ValidateIntegrationConfiguration(string integrationConfig, int tenantsCount, string defaultAddress, string redirectedAddress)
        {
            string[] lines = SplitIntoLines(integrationConfig.Trim());
            Assert.That(lines.Length, Is.EqualTo(3 + tenantsCount));
            Assert.That(lines[0], Is.EqualTo("map $integrationtenant $integrationlandscape {"));
            Assert.That(lines[lines.Length - 1], Is.EqualTo("}"));
            for (int i = 1; i < lines.Length - 1; i++)
            {
                if (lines[i].Contains("\tdefault"))
                {
                    Assert.That(lines[i], Is.EqualTo($"\tdefault\t\"{defaultAddress}\";"));
                }
                else
                {
                    string ip = lines[i].Split('\t')[2].Replace("\"", "").Replace(";", "");
                    Assert.That(ip, Is.EqualTo(redirectedAddress));
                }
            }
        }

        private void PrepareConfigFile(string ccfUri, string hostIm, string hostImAlternate, string hostIntegration, string hostIntegrationAlternate, string ccfMaxRetryCount, string ccfRetryTimeout)
        {
            string config = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>" +
                "<configuration>" +
                    "<appSettings>" +
                        "<add key=\"centralconfig_uri\" value=\"" + ccfUri + "\"/>" +
                        "<add key=\"host_im_alternate\" value=\"" + hostImAlternate + "\"/>" +
                        "<add key=\"host_integration_alternate\" value=\"" + hostIntegrationAlternate + "\"/>" +
                        "<add key=\"AGENTTASKWEBSERVICE_SERVICE_HOST\" value=\"" + hostIm + "\"/>" +
                        "<add key=\"INBOUNDWEBSERVICE_SERVICE_HOST\" value=\"" + hostIntegration + "\"/>" +
                        "<add key=\"centralconfig_max_retry_count\" value=\""+ccfMaxRetryCount+"\"/>" +
                        "<add key=\"centralconfig_retry_timeout_ms\" value=\""+ccfRetryTimeout+"\"/>" +
                    "</appSettings>" +
                "</configuration>";
            File.WriteAllText(Path.Combine(
                Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location),
                "RuleEngine.dll.config"
            ), config);
        }

        private string[] SplitIntoLines(string fileContent) => fileContent.Split(
            new string[] { "\r\n", "\r", "\n" },
            StringSplitOptions.None
        );

        #region Powershell support methods

        private void LaunchContainer()
        {
            StopContainer();
            using PowerShell ps = PowerShell.Create();
            ps.AddScript(LaunchContainerScript);
            ps.Invoke();
        }

        private bool CheckIfContainerIsRunning()
        {
            using PowerShell ps = PowerShell.Create();
            ps.AddScript("docker ps -a -q --filter=\"name=rule-image\"");
            var output = ps.Invoke();
            return output.Count() > 0;
        }

        private void StopContainer()
        {
            using PowerShell ps = PowerShell.Create();
            ps.AddScript(StopContainerScript);
            ps.Invoke();
        }

        private string GetIMConfigurationFromContainer()
        {
            using PowerShell ps = PowerShell.Create();
            ps.AddScript("docker exec $(docker ps -a -q --filter=\"name=rule-image\") cat /etc/nginx/rules.im.conf");
            var output = ps.Invoke();
            StringBuilder sb = new StringBuilder();
            foreach (var x in output)
            {
                sb.AppendLine(x.BaseObject.ToString());
            }
            return sb.ToString();
        }

        private string GetIntegrationConfigurationFromContainer()
        {
            using PowerShell ps = PowerShell.Create();
            ps.AddScript("docker exec $(docker ps -a -q --filter=\"name=rule-image\") cat /etc/nginx/rules.integration.conf");
            var output = ps.Invoke();
            StringBuilder sb = new StringBuilder();
            foreach (var x in output)
            {
                sb.AppendLine(x.BaseObject.ToString());
            }
            return sb.ToString();
        }

        #endregion
    }
}
