import { Component, OnInit } from '@angular/core';
import { LogsService } from 'src/app/services/apis/logs.service';
import { LoaderService } from 'src/app/services/controls/loader.service';

@Component({
  selector: 'app-sync',
  templateUrl: './sync.component.html',
  styleUrls: ['./sync.component.scss']
})
export class SyncComponent implements OnInit {

  constructor(
    public api: LogsService,
    public loader: LoaderService
  ) { }

  ngOnInit(): void {
    this.sync();
    this.clock();
  }

  clock() {
    setInterval(() => {
      if(this.sync_time>0){
        this.sync_time = this.sync_time - 1;
        this.sync_sub_message = 'Last updated ' + (this.sync_response.interval-this.sync_time) + 'm ago';
      }
      else{
        this.sync();
      }
    }, 60000);
  }

  sync_response: any;
  sync_message: any;
  sync_sub_message: any;
  sync_time: any;
  state: any = 0; // 0: unknown, 1: sync, 2: update, 3: wait, 4: error

  sync() {
    this.sync_message = 'Syncing...';
    this.state = 1;
    this.api.update().subscribe(
      (data: any) => {
        this.sync_response = data;
        if(this.sync_response.updated==true) {
          this.sync_message = 'Sync Complete';
          this.state = 2;
        }
        else{
          this.sync_message = 'Already up to date';
          this.state = 3;
          var timeStamp = new Date(this.sync_response.timestamp);
          var update_time = new Date(timeStamp.getTime() + this.sync_response.interval*60000);
          var diff = update_time.getTime() - new Date().getTime();
          this.sync_time = Math.floor(diff/60000);
          this.sync_sub_message = 'Last updated ' + (this.sync_response.interval-this.sync_time) + 'm ago';
        }
      },
      (error: any) => {
        console.log(error);
        this.state = 4;
      }
    );
  }

}
