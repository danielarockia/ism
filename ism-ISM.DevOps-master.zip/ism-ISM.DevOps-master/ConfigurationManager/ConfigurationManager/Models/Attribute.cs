﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationManager.Models
{
    public class Attribute
    {
        public string type="attribute";
        public string path;
        public string selector;
        public string selectorValue;
        public string attribute;
        public string value;
    }
}
