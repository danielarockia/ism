import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LogsService {

  url = environment.url;

  constructor(private http: HttpClient) { }

  getDeployments(): any {
    const httpOptions = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    };
    const data = this.http.get(
      this.url + 'deployments'
      // {
      //   headers: new HttpHeaders(httpOptions)
      // }
    );
    return data;
  }

  getPods(namespace: string): any {
    const data = this.http.get(
      this.url + 'pods'
    );
    return data;
  }

  getEnv(namespace: string, application: string): any {
    let params = new HttpParams();
    params = params.append('namespace', namespace);
    params = params.append('application', application);
    const data = this.http.get(
      this.url + 'secret',
      {
        params: params
      }
    );
    return data;
  }

  getLogs(application: string): any {
    let params = new HttpParams();
    params = params.append('application', application);
    const data = this.http.get(
      this.url + 'logs',
      {
        params: params
      }
    );
    return data;
  }

  update(): any {
    const data = this.http.get(this.url + 'update');
    return data;
  }

  getNodes(): any {
    const data = this.http.get(
      this.url + 'cluster'
    );
    return data;
  }

  getPipelines(): any {
    const data = this.http.get(
      this.url + 'pipelines'
    );
    return data;
  }

  updateTracked(payload: any): any {
    const data = this.http.post(
      this.url + 'updateTracked',
      payload
    );
    return data;
  }

  getTracked(): any {
    const data = this.http.get(
      this.url + 'tracked'
    );
    return data;
  }

  getTrackingInfo(id: string): any {
    let params = new HttpParams();
    params = params.append('pipelineId', id);
    const data = this.http.get(
      this.url + 'trackInfo',
      {
        params: params
      }
    );
    return data;
  }

  updateWorkflow(payload: any): any {
    const data = this.http.post(
      this.url + 'updateWorkflow',
      payload
    );
    return data;
  }

  getWorkflow(): any {
    const data = this.http.get(
      this.url + 'workflow'
    );
    return data;
  }

  runPipeline(id: any): any {
    let params = new HttpParams();
    params = params.append('id', id);
    const data = this.http.get(
      this.url + 'trackInfo',
      {
        params: params
      }
    );
    return data;
  }

  check(id: any):any {
    return 'success';
  }
}
