from string import Template
import argparse, sys
import globals

def loadTemplate(templateSource):
    file = open(templateSource, 'r')
    data = file.read()
    file.close()
    template = Template(data)
    return template

def generateFromTemplate(template, mapping):
    print(mapping)
    data = template.safe_substitute(**mapping)
    return data

def getIndentation(template, key):
    key = '${' + key +'}'
    lines = template.split('\n')
    for line in lines:
        if key in line:
            return len(line) - len(line.lstrip(' '))
    return 0

def save(data):
    file = open(globals.MANIFEST_FILE, 'w')
    file.write(data)
    file.close()

def generate(name, image, registry, secret):
    mapping = {
        'name'      :   name,
        'repo'      :   name,
        'image'     :   image,
        'registry'  :   registry,
        'secret'    :   secret
    }
    if name.startswith('sm.'):
        mapping['name'] = name[3:]
    cacheImageTemplate = loadTemplate(globals.CACHE_IMAGE_TEMPLATE)
    cacheImage = generateFromTemplate(cacheImageTemplate, mapping)
    # print(cacheImage)

    daemonSetTemplate = loadTemplate(globals.DAEMONSET_TEMPLATE)
    daemonSetCache = 'cache'
    # print(str(daemonSetTemplate.template))

    indentLevel = getIndentation(daemonSetTemplate.template, daemonSetCache)
    cacheImage = cacheImage.splitlines()
    cacheImage = [(lambda x : ' '*indentLevel + x)(x) for x in cacheImage]
    cacheImage = '\n' + '\n'.join(cacheImage)
    daemonSet = generateFromTemplate(daemonSetTemplate, {daemonSetCache:cacheImage, 'secret':mapping['secret']})
    # print(daemonSet)
    return daemonSet

# data = generate()
# save(data)