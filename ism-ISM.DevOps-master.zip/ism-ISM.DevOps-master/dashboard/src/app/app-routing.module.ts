import { DeploymentComponent } from './layout/pages/deployment/deployment.component';
import { RolloutplanComponent } from './layout/pages/rolloutplan/rolloutplan.component';
import { RolloutComponent } from './layout/pages/rollout/rollout.component';
import { ReleaseComponent } from './layout/pages/release/release.component';
import { LogsComponent } from './layout/pages/logs/logs.component';
import { LogsService } from 'src/app/services/apis/logs.service';
import { EnvironmentComponent } from './layout/pages/environment/environment.component';
import { PodsComponent } from './layout/pages/pods/pods.component';
import { DeploymentsComponent } from './layout/pages/deployments/deployments.component';
import { ErrorComponent } from './layout/pages/error/error.component';
import { DashboardComponent } from './layout/pages/dashboard/dashboard.component';
import { LayoutComponent } from './layout/app/layout/layout.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: '', component: DashboardComponent },
      { path: 'Dashboard', component: DashboardComponent },
      { path: 'Pipelines', component: ReleaseComponent },
      { path: 'Rollouts', component: RolloutComponent },
      { path: 'RolloutPlan', component: RolloutplanComponent },
      { path: 'Deployment', component: DeploymentComponent },
      { path: 'Deployments', component: DeploymentsComponent },
      { path: 'Pods', component: PodsComponent },
      { path: 'Environment', component: EnvironmentComponent },
      { path: 'Logs', component: LogsComponent },
      { path: 'Logs/:id', component: LogsComponent },
      { path: '**', component: ErrorComponent }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
