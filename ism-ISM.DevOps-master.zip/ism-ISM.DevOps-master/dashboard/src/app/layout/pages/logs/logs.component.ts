import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LogsService } from 'src/app/services/apis/logs.service';
import { LoaderService } from 'src/app/services/controls/loader.service';
import { AnsiUp } from 'ansi-up';
import { DomSanitizer } from '@angular/platform-browser';
import { HighlightService } from 'src/app/services/highlight.service';
import * as Prism from 'prismjs';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LogsComponent implements OnInit {

  highlighted: boolean = false;

  constructor(
    private route: ActivatedRoute,
    public api: LogsService,
    public loader: LoaderService,
    private sanitizer: DomSanitizer,
    private highlightService: HighlightService
  ) { }

  deployment: any = '';
  log: any = '';
  log_raw: any = '';
  view_only: any = false;
  modes = ['Bash ANSI','HTML', 'Code/JSON', 'None']
  mode: any = this.modes[0];
  deployments: any;
  DATA: any[] = [];
  namespaces = [];
  applications:any[] = [];
  ansi_up = new AnsiUp();

  ngOnInit(): void {
    this.deployment = this.route.snapshot.paramMap.get('id');
    console.log('==============SubModule========');
    console.log(this.deployment);
    if(this.deployment!=null){
      this.view_only = true;
      this.show(this.deployment);
    }
    this.get_deployments();
  }

  get_deployments() {
    this.loader.show();
    this.api.getDeployments().subscribe(
      (data: any) => {
        this.deployments = data;
        console.log(this.deployments);
        this.show_deployment(this.get_namespaces()[0]);
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_logs(application: any) {
    this.loader.show();
    this.api.getLogs(application).subscribe(
      (data: any) => {
        this.log_raw = data;
        this.highlight(data);
        // console.log('====================================');
        // console.log(this.log_raw);
        // console.log('====================================');
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  show_deployment(namespace: string) {
    let keys = Object.keys(this.deployments[namespace]);
    this.DATA = [];
    for(let i=0; i<keys.length; i++){
      let row: any = this.deployments[namespace][keys[i]];
      row['name'] = keys[i];
      row['position']  = i+1;
      this.DATA.push(row);
    }
    this.applications = keys;
  }

  get_namespaces() {
    let namespaces = Object.keys(this.deployments);
    return namespaces;
  }

  onChange(namespace: any) {
    this.show_deployment(namespace)
  }

  show(application: any) {
    this.get_logs(application)
  }

  highlight(data: any): any{
    if(this.mode==='Bash ANSI'){
      this.log = this.ansi_up.ansi_to_html(data);
    }
    else if(this.mode==='HTML'){
      this.log = Prism.highlight(data, Prism.languages.html);
    }
    else if(this.mode==='Code/JSON'){
      this.log = Prism.highlight(data, Prism.languages.javascript);
    }
    else{
      this.log = data;
    }
  }

  sa(data: any): any{
    if (data){
      return this.sanitizer.bypassSecurityTrustHtml(data);
    }
    else{
      return 'No Data';
    }
  }

  changeMode(mode: any){
    this.mode = mode;
    this.highlight(this.log_raw);
  }
}
