﻿using RuleEngine.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine.Controllers
{
    public static class ApiKeyController
    {
        public static string centralConfigApiKeyName = "central-config-api-key";
        public static string GetApiKey(string keyName)
        {
            SecretStorageHelper secretStorage = new SecretStorageHelper();
            var apiKey = secretStorage.GetSecretAsync(keyName, CancellationToken.None).Result?.Value;
            Logging.Log("CCF API KEY = "+apiKey, Logging.LogLevel.Debug);
            return apiKey;
        }
    }
}
