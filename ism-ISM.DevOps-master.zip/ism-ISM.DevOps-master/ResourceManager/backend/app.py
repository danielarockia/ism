import os
import ssl
from flask import Flask, request, abort
from pymongo import MongoClient
from flask_cors import CORS
import json
import copy

app = Flask(__name__)
CORS(app)

#region Helpers

def treeify(node, path=[]):
  if len(node)==0:
    return None

  res_children = []

  for item in node:
    res_node_value = treeify(node[item], path + [item])
    res_node = {
      'name': item,
    }
    if res_node_value!=None:
      res_node['children'] = res_node_value
    else:
      res_node['landscape'] = '-'.join( (path + [item]) [::-1])
    res_children.append(res_node)

  return res_children

def sanitize(value):
  # quotes
  value = value.strip('\"')
  try:
    # number
    value = eval(value)
  except:
    # boolean
    if value in ["true", "false"]:
      return value=="true"
  return value

def schematize(schema, values):
  record = copy.deepcopy(schema)
  if type(record) == type(dict()):
    for key in record:
      if type(record[key]) == type(dict()):
        record[key] = schematize(record[key], values)
      else:
        if key in values:
          record[key] = sanitize(values[key])
  return record

def flatten(record):
  res = dict()
  for key in record:
    if type(record[key]) == type(dict()):
      subrecord = flatten(record[key])
      for subkey in subrecord:
        res[subkey] = subrecord[subkey]
    else:
      res[key] = record[key]
  return res

#endregion Helpers

#region DB

def getForm(landscape, application):
  collection = db[landscape]
  document = collection.find_one({'application': application}, {'_id': 0, 'data': 1})
  try:
    return document['data']
  except:
    return {}

def getSchema(name):
  collection = config_db['schemas']
  document = collection.find_one({'name': name}, {'_id': 0, 'schema': 1})
  try:
    return document['schema']
  except:
    return {}

def updateSchema(name, data):
  collection = config_db['schemas']
  document = collection.find_one({'name': name}, {'_id': 0, 'schema': 1})
  updateResult = collection.update_one({'name': name}, {'$set': {'name': name, 'schema': data}}, upsert=True)
  return updateResult.matched_count==1

def getSchemas():
  collection = config_db['schemas']
  documents = collection.find({}, {'_id': 0, 'name': 1})
  try:
    res = []
    for document in documents:
      res.append(document['name'])
    return res
  except:
    return []

def getTable(landscape):
  collection = db[landscape]
  document = collection.find({}, {'_id': 0, 'application': 1, 'data': 1})
  try:
    return document
  except:
    return {}

def updateForm(landscape, application, data):
  collection = db[landscape]
  document = collection.find_one({'application': application}, {'_id': 0, 'data': 1})
  updateResult = collection.update_one({'application': application}, {'$set': {'application': application, 'data': data}}, upsert=True)
  return updateResult.upserted_id==1 or updateResult.modified_count==1

#endregion DB

#region API
@app.route('/schemas/<name>', methods=['GET'])
def get_schema(name):
  schema = getSchema(name)
  return json.dumps(schema)

@app.route('/schemas/<name>/table', methods=['GET'])
def get_schema_flat(name):
  schema = getSchema(name)
  schema = flatten(schema)
  res = []
  for key in schema:
    value = ' '.join(key.upper().split('_'))
    res.append({
      'key'   : key,
      'title' : value
    })
  return json.dumps(res)

@app.route('/schemas', methods=['GET'])
def get_schema_list():
  schema = getSchemas()
  return json.dumps(schema)

@app.route('/schema/<name>', methods=['GET'])
def get_schema1(name):
  table = getSchema(name)
  res = {}
  for key in table:
    res[key] = table[key]
  return json.dumps(res)

@app.route('/schema/<name>', methods=['POST', 'PUT'])
def update_schema1(name):
  data = request.get_json()
  print(data)
  if(updateSchema(name, data)):
      return json.dumps('Saved')
  else:
    abort(404)

@app.route('/resources/<landscape>/<application>', methods=['GET'])
def get_resources(landscape, application):
  form = getForm(landscape, application)
  return json.dumps(form)

@app.route('/resources/<landscape>/<application>/flat', methods=['GET'])
def get_resources_flat(landscape, application):
  form = getForm(landscape, application)
  form = flatten(form)
  return json.dumps(form)

@app.route('/resources/<landscape>', methods=['GET'])
def get_table(landscape):
  table = getTable(landscape)
  res = []
  for row in table:
    res.append(row)
  return json.dumps(res)

@app.route('/resources/<landscape>/table', methods=['GET'])
def get_table_flat(landscape):
  table = getTable(landscape)
  res = []
  for row in table:
    res.append(flatten(row) )
  return json.dumps(res)

@app.route('/resources/<landscape>/<application>', methods=['POST', 'PUT'])
def update_resources(landscape, application):
  data = request.get_json()
  print(data)
  if(updateForm(landscape, application, data)):
      return json.dumps('Saved')
  else:
    abort(404)

@app.route('/list', methods=['GET'])
def list_landscapes():
  resources = db.list_collection_names()
  table = dict()
  for item in resources:
    parts = item.split('-')
    holder = table
    for part in parts[::-1]:
      if part not in holder:
        holder[part] = dict()
      holder = holder[part]
  tree = treeify(table)
  return json.dumps(tree)

@app.route('/import/<landscape>', methods=['GET', 'POST'])
def import_excel(landscape):
  schema = getSchema('terraform')
  data = request.data.decode("utf-8")
  res = []
  data = json.loads(data)
  rows = data.split('\n')
  headers = rows[0].split('\t')
  print(len(headers), ':', headers)
  for row in rows[1:]:
    if row=='': continue
    document = dict()
    values = row.split('\t')
    print(len(values), ':', values)
    for i in range(len(headers)):
      document[headers[i]] = values[i]
    record = schematize(schema, document)
    res.append(record)
  count = 0
  for document in res:
    o=updateForm(landscape, document['application'], document)
    if o==True: count += 1
  return json.dumps(str(count) + ' Records Added')

#endregion API

if __name__ == '__main__':
  CONNECTION_STRING = "mongodb+srv://admin:xXkU2vqoBMGfEKldmxTNhuH6@cluster0.c9xhi.mongodb.net/myFirstDatabase?authSource=admin"
  PORT = 80
  if  "MONGO_CS" in os.environ:
    CONNECTION_STRING = os.environ['MONGO_CS']
    PORT = 80

  client = MongoClient(CONNECTION_STRING, 27017, ssl_cert_reqs=ssl.CERT_NONE)
  db = client.Resources
  config_db = client.RMConfig
  app.run(host="0.0.0.0", port=PORT, debug=True)
