﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ConfigurationManager.Helpers;
using ConfigurationManager.Models;
using Newtonsoft.Json;

namespace ConfigurationManager.Modules
{
    class Configurator
    {
        private List<Models.Attribute> _attributes = new List<Models.Attribute>();
        private List<Models.Property> _properties = new List<Models.Property>();
        private String configFile = String.Empty;

        private XmlDocument doc = new XmlDocument();

        public void getConfigurations()
        {
            BlobStorageHelper blobStorage = new BlobStorageHelper();
            blobStorage.init();
            configFile = blobStorage.downloadFile();
        }

        public void init()
        {
            JsonHelper jsonHelper = new JsonHelper();
            var json = jsonHelper.LoadData(configFile);

            JsonSerializer serializer = new JsonSerializer();

            if (json != null)
            {
                foreach(var item in json)
                {

                    string type = item.type;
                    switch (type)
                    {
                        case "attribute":
                            //Models.Attribute attributeElement = JsonConvert.DeserializeObject<Models.Attribute>(item);
                            
                            var serializedAttribute = JsonConvert.SerializeObject(item);
                            Models.Attribute attributeElement = JsonConvert.DeserializeObject<Models.Attribute>(serializedAttribute);
                            _attributes.Add(attributeElement);
                            break;
                        case "property":
                            var serializedProperty = JsonConvert.SerializeObject(item);
                            Models.Property propertyElement = JsonConvert.DeserializeObject<Models.Property>(serializedProperty);
                            _properties.Add(propertyElement);
                            break;
                        default:
                            Console.WriteLine("Item skipped");
                            break;
                    }
                }
            }
            else
            {
                throw new Exception("Configurator: Null Object Reference");
            }
        }

        private void setAttributes()
        {
            foreach(Models.Attribute attribute in _attributes)
            {
                var updatedDoc = XmlHelper.updateAttribute(doc, attribute);
                if (updatedDoc != null)
                {
                    doc = updatedDoc;
                }
                else
                {
                    throw new Exception("Unable to process : " + attribute.ToString());
                }
            }
        }

        private void setProperties()
        {
            foreach (Models.Property property in _properties)
            {
                var updatedDoc = XmlHelper.UpdateProperty(doc, property);
                if (updatedDoc != null)
                {
                    doc = updatedDoc;
                }
                else
                {
                    throw new Exception("Unable to process : " + property.ToString());
                }
            }
        }

        public void Load(string FILE)
        {
            doc.Load(FILE);
        }

        public void Configure(string FILE)
        {
            configFile = FILE;
        }

        public void Save(string FILE)
        {
            doc.Save(FILE);
        }

        public XmlDocument Run()
        {
            setAttributes();
            setProperties();
            return doc;
        }
    }
}
