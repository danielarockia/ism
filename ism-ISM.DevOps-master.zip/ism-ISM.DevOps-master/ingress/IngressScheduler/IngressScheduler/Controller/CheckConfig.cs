﻿using IngressScheduler.Interfaces;
using System;
using System.IO;

namespace IngressScheduler.Controller
{
    public static class CheckConfig
    {
        public static bool exists(ISettings settings, string configFilePath)
        {
            DirectoryInfo dir = new DirectoryInfo(configFilePath);
            Console.WriteLine("Searching in " + dir.FullName);
            FileInfo[] Files = dir.GetFiles("*");
            foreach (FileInfo file in Files)
            {
                //Console.WriteLine("+ "+file.Name);
                if (file.Name == settings.Load("kubeconfigfile"))
                {
                    Console.WriteLine("Config File Detected.");
                    return true;
                }
            }
            Console.WriteLine("Config File Missing.");
            return false;
        }
    }
}
