from kubernetes import client, config, utils
from prettytable import PrettyTable
import os
import globals

def create():
    command = 'kubectl apply -f '+globals.MANIFEST_FILE
    os.system(command)