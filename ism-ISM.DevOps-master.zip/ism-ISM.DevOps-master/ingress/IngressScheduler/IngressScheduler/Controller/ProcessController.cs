﻿using BetterConsoleTables;
using IngressScheduler.Helpers;
using IngressScheduler.Interfaces;
using IngressScheduler.Models;
using k8s;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Action = IngressScheduler.Models.Action;

namespace IngressScheduler.Controller
{
    public class ProcessController
    {
        public static void ProcessIngress(ISettings settings, IKubernetes client, List<string> tenants)
        {
            try
            {
                if (client == null) {
                    Logging.Log("Kubernetes Connection Error", Logging.LogLevel.Error);
                    return;
                }

                LoadData.Invoke(settings);

                Table table = RulesController.CreateTable(tenants);

                List<Ingress> ingressList = KubernetesIngress.GetIngress(client, null);

                RulesController.GetFinalActionList(settings, client, tenants, ingressList, out Dictionary<string, List<Action>> actionTargets, out Dictionary<string, int> actions);

                Logging.Log("Action Targets...", Logging.LogLevel.Debug);
                Debug.printTargets(actionTargets);

                Schedule(settings, client, actionTargets, actions);
            }
            catch (Exception ex)
            {
                Logging.Log(ex);
            }
        }

        public static void Schedule(ISettings settings, IKubernetes client, Dictionary<string, List<Action>> actionTargets, Dictionary<string, int> actions)
        {
            foreach (KeyValuePair<string, int> action in actions)
            {
                Logging.Log(action.Key + ":" + action.Value, Logging.LogLevel.Info);
                switch (action.Value)
                {
                    case -1:
                        // Remove
                        Logging.Log("[DELETE]\t" + action.Key, Logging.LogLevel.Info);
                        if (actionTargets.ContainsKey(action.Key) && SafetyProtection.CheckStatus(settings))
                        {
                            foreach (Action actionTarget in actionTargets[action.Key])
                            {
                                try
                                {
                                    Logging.Log("Delete " + actionTarget.Application + (actionTarget.Root ? "[base]" : ""), Logging.LogLevel.Info);
                                    KubernetesIngress.DeleteIngress(
                                        client: client,
                                        host: action.Key,
                                        appName: actionTarget.Application,
                                        appNamespace: Applications.applicationList[actionTarget.Application].Namespace,
                                        root: actionTarget.Root
                                    );
                                }
                                catch (Exception ex)
                                {
                                    Logging.Log(ex.Message, Logging.LogLevel.Error);
                                }
                            }
                        }
                        break;

                    case 0:
                        // Ignore
                        //KubernetesIngress.UpdateIngress(client, action.Key, appName, appNamespace);
                        Logging.Log("[EXISTS]\t" + action.Key, Logging.LogLevel.Info);
                        break;

                    case 1:
                        // Add
                        Logging.Log("[CREATE]\t" + action.Key, Logging.LogLevel.Info);
                        if (actionTargets.ContainsKey(action.Key))
                        {
                            foreach (Action actionTarget in actionTargets[action.Key])
                            {
                                //if (!actionTarget.Root) continue;
                                Logging.Log("Add " + actionTarget.Application + (actionTarget.Root ? "[base]" : ""), Logging.LogLevel.Info);
                                KubernetesIngress.CreateIngress(
                                    client: client,
                                    host: action.Key,
                                    appName: actionTarget.Application,
                                    appNamespace: Applications.applicationList[actionTarget.Application].Namespace,
                                    root: actionTarget.Root
                                );
                            }
                        }

                        break;

                    case 2:
                        // Update
                        Logging.Log("[UPDATE]\t" + action.Key, Logging.LogLevel.Info);
                        if (actionTargets.ContainsKey(action.Key) && SafetyProtection.CheckStatus(settings))
                        {
                            foreach (Action actionTarget in actionTargets[action.Key])
                            {
                                Logging.Log("Add " + actionTarget.Application + (actionTarget.Root ? "[base]" : ""), Logging.LogLevel.Info);
                                KubernetesIngress.CreateIngress(
                                    client: client,
                                    host: action.Key,
                                    appName: actionTarget.Application,
                                    appNamespace: Applications.applicationList[actionTarget.Application].Namespace,
                                    root: actionTarget.Root
                                );
                            }
                        }
                        break;

                    default:
                        break;
                }
                Task.Delay(2 * 1000).Wait();
            }
        }
    }
}
