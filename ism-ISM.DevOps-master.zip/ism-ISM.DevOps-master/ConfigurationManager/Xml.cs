﻿using System;
using System.Xml;

namespace ConfigurationManager
{
    public class Xml
    {
        public Configure()
        {
            
    }
}

