# from pymongo.message import insert
from ISMLogBackend.database.insert import timeseries
import ISMLogBackend.global_vars as globals
import helpers.kube as kube
import helpers.file_handling as file_handler
from database.insert import timeseries as save, timeseriesMany as save_all

def getEnv(namespace, pod, os, client):
    env = None
    if(os=='linux'):
        env = kube.getInternalVariables(pod, namespace, client)
    else:
        env = kube.getInternalVariables(pod, namespace, client, True)
    return env

def saveLog(namespace, deployment, pod, logs, error):
    save(
        globals.TABLE_LOGS,
        {
            'namesapce': namespace,
            'pod': pod,
            'deployment': deployment,
            'logs': logs,
            'error': False
        }
    )

def saveLogs(data):
    save_all(globals.TABLE_LOGS, data)

def getSaveLog(namespace, deployment, pod, logs, error):
    return {
        'namesapce': namespace,
        'pod': pod,
        'deployment': deployment,
        'logs': logs,
        'error': False
    }


def fullCheck(namespace, v1):
    c = 0
    pods, deployments = kube.getPods(namespace, v1)

    envData = dict()
    logData = []

    for deployment in pods:
        status = deployments[deployment]['status']
        c+=1

        os = deployments[deployment]['os']
        pod = pods[deployment][0]
    
        if status:
            # Environment Variables
            # envData[deployment] = getEnv(namespace, pod, os, v1) 

            # Logs
            logs = kube.getLogs(pods[deployment][0], namespace, v1)
            logData.append(getSaveLog(namespace, deployment, pod, logs, False))
            
        else:
            # Error Logs
            logs = kube.getLogs(pods[deployment][0], namespace, v1)
            logData.append(getSaveLog(namespace, deployment, pod, logs, True))

    services = kube.getServices(namespace, v1)
    saveLogs(logData)
    return pods, deployments, services

def secret(namespace, application, v1):
    return kube.getSecret(namespace, application+'-parameters', v1)