import os
import sys

repos = {
    'elasticsearch': ['https://helm.elastic.co','elasticsearch', True],
	# 'ingress': ['https://charts.helm.sh/stable', 'nginx-ingress', True],
	'ingress': ['https://kubernetes.github.io/ingress-nginx', 'ingress-nginx', True],
	'grafana': ['https://grafana.github.io/helm-charts', 'grafana', True],
	'kedacore': ['https://kedacore.github.io/charts', 'keda', True],
}

alias = {
	'ingress'	:	'network',
	'kedacore'	:	'keda'
}

namespace_map = {
	'kedacore'	:	'autoscaling',
	'grafana'	:	'autoscaling'
}

if(len(sys.argv) not in [2,3] or sys.argv[1]=='-h'):
	print('helm.py [module] [namespace]<optional>')
	sys.exit()

ENV='dev'
module = sys.argv[1]
namespace = module
if namespace in namespace_map:
	namespace = namespace_map[namespace]
if len(sys.argv)>2:
	namespace = sys.argv[2]
repo = repos[module][0]
enable_config = repos[module][2]
config = './helm/values'+'/'+module+'.'+ENV+'.yaml'
app_name = module + '/' + repos[module][1]

print('Helm')
os.system('helm repo list')
os.system('helm repo remove '+module)
os.system('helm repo add '+module+' '+repo)
os.system('helm repo list')
os.system('helm repo update')
if module in alias:
	module = alias[module]
INSTALL_COMMAND = 'helm upgrade --install {0} {1} -n {2}'.format(module, app_name, namespace)
if enable_config:
	INSTALL_COMMAND += ' -f ' + config
print(INSTALL_COMMAND)
os.system(INSTALL_COMMAND)