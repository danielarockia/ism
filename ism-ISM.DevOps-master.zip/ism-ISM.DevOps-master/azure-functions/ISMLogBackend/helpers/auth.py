from ISMLogBackend.global_vars import CONFIG_FILE
import os

CLUSTER         =   'AKS-RG-{region}-{landscape}-ISM'
RESOURCE_GROUP  =   'RG-{region}-{landscape}-ISM'

def getConfig(region, landscape):
    region      =   region.upper()
    landscape   =   landscape.upper()
    data = {
        'config'    :   CONFIG_FILE,
        'cluster'   :   CLUSTER.format(region=region, landscape=landscape),
        'rg'        :   RESOURCE_GROUP.format(region=region, landscape=landscape)
    }
    os.system('az aks get-credentials --name {cluster} --resource-group {rg} -a -f {config}'.format(**data))

def getGlobalConfig(region, landscape):
    region      =   region.upper()
    landscape   =   landscape.upper()
    data = {
        'config'    :   CONFIG_FILE,
        'cluster'   :   CLUSTER.format(region=region, landscape=landscape),
        'rg'        :   RESOURCE_GROUP.format(region=region, landscape=landscape)
    }
    os.system('az aks get-credentials --name {cluster} --resource-group {rg} -a')

def clearConfig():
    if os.path.isfile(CONFIG_FILE):
        os.remove(CONFIG_FILE)
        print('Removed existing config file')
    else:
        print('No existing config file')