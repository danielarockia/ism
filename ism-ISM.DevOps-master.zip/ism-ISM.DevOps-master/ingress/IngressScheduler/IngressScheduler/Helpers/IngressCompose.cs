﻿using IngressScheduler.Models;
using k8s.Models;
using System.Collections.Generic;

namespace IngressScheduler.Helpers
{
    public static class IngressCompose
    {
        public static string prefix = "auto-";
        public static string base_key = "-base";

        public static Dictionary<string, string> createLabel(string appName)
        {
            Dictionary<string, string> labels = new Dictionary<string, string>()
            {
                { "App", appName }
            };
            return labels;
        }

        public static V1Ingress compose(string host, string appName, string appNamespace, string suffix = "", bool root = false)
        {
            string tenant = "";
            string domain = "";
            if (host != null)
            {
                int hostSplitIndex = host.IndexOf('.');
                tenant = host.Substring(0, hostSplitIndex);
                domain = host.Substring(hostSplitIndex + 1);
            }
            else
            {
                //host = "*";
                tenant = "";
                domain = "*";
            }

            string base_suffix = "";

            if (root == true)
            {
                base_suffix = base_key;
            }

            string name = prefix + appName + "-" + tenant + base_suffix + suffix;

            // Create Metadata
            V1ObjectMeta metadata = CreateMetadata(name, appName, appNamespace);

            //Create Service
            V1IngressServiceBackend service = CreateService(appName, 80);

            //Create Rule
            string applicationPath = "";
            if (Applications.applicationList.ContainsKey(appName))
            {
                applicationPath = Applications.applicationList[appName].Path;
            }
            else if (Applications.staticApplicationList.ContainsKey(appName))
            {
                applicationPath = Applications.staticApplicationList[appName].Path;
            }

            if (root)
            {
                if (applicationPath.Contains('/'))
                {
                    int rootEndPosition = applicationPath.LastIndexOf('/');
                    applicationPath = applicationPath[..rootEndPosition];
                }
                else
                {
                    applicationPath = "/";
                }
            }

            V1HTTPIngressPath path = new V1HTTPIngressPath(
                backend: new V1IngressBackend(service: service),
                pathType: "ImplementationSpecific",
                path: applicationPath
            );
            V1IngressRule rule = new V1IngressRule(
                host: host,
                http: new V1HTTPIngressRuleValue(new List<V1HTTPIngressPath>() { path })
            );

            // Create TLS
            //Console.WriteLine(" - Certificate = " + domain);
            V1IngressTLS tls = new V1IngressTLS(new List<string>() { host }, domain);

            // Create SPEC
            V1IngressSpec spec = new V1IngressSpec();
            spec.Rules = new List<V1IngressRule>() { rule };
            if (host != null)
            {
                spec.Tls = new List<V1IngressTLS>() { tls };
            }

            // Create Ingress
            V1Ingress ingress = new V1Ingress(
                metadata: metadata,
                spec: spec
            );
            ingress.Validate();
            return ingress;
        }

        private static V1ObjectMeta CreateMetadata(string name, string appName, string appNamespace)
        {
            V1ObjectMeta metadata = new V1ObjectMeta();
            metadata.Name = name;
            metadata.NamespaceProperty = appNamespace;
            metadata.Annotations = Annotations.Load(appName); ;
            metadata.Labels = createLabel(appName);
            metadata.Generation = 2;
            metadata.Validate();
            return metadata;
        }

        private static V1IngressServiceBackend CreateService(string appName, int port)
        {
            V1IngressServiceBackend service = new V1IngressServiceBackend(
                name: appName,
                port: new V1ServiceBackendPort(number: port)
            );
            return service;
        }
    }
}
