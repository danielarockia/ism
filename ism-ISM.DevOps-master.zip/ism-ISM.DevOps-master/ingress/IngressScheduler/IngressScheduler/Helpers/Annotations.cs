﻿using IngressScheduler.Controller;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;

namespace IngressScheduler.Helpers
{
    public static class Annotations
    {
        public static Dictionary<string, string> Load(string application)
        {
            string getAnnotation(string application)
            {
                switch (application)
                {
                    case "appserver-external":
                        application = "appserver";
                        break;
                    case "default":
                        break;
                }
                return application;
            }
            string annotationFile = "Data/annotations/" + getAnnotation(application) + ".json";
            if (!File.Exists(annotationFile))
            {
                annotationFile = "Data/annotations/default.json";
            }
            Logging.Log("Annotations:" + annotationFile, Logging.LogLevel.Debug);
            using (StreamReader r = new StreamReader(annotationFile))
            {
                string json = r.ReadToEnd();
                var annotations = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                return annotations;
            }
        }
    }
}
