﻿using ConfigurationManager.Helpers;
using ConfigurationManager.Modules;
using System;
using System.Collections.Generic;
using System.Xml;

namespace ConfigurationManager
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            ArgumentHelper argumentHelper = new ArgumentHelper(args);
            if (argumentHelper.validity)
            {
                data = argumentHelper.get();
            }
            else return;

            Configurator configurator = new Configurator();

            if (data.ContainsKey("ConfigFile"))
            {
                configurator.Configure(data["ConfigFile"]);
            }
            else
            {
                configurator.getConfigurations();
            }
            configurator.init();
            configurator.Load(data["InputConfig"]);
            configurator.Run();
            configurator.Save(data["OutputConfig"]);
        }
    }
}
