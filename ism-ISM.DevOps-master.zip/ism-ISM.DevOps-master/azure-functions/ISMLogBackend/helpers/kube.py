from kubernetes import client, config
from kubernetes.client.rest import ApiException
from kubernetes.client.api import core_v1_api
from kubernetes.stream import stream

import helpers.file_handling as file_handler

# Get all Pods
def getPods(namespace, v1):
    ret = v1.list_namespaced_pod(namespace, watch=False)
    pods = dict()
    deployments = dict()
    for item in ret.items:
        name = item.metadata.name
        os = item.spec.node_selector['beta.kubernetes.io/os']
        status = item.status.container_statuses[0].started
        deployment = name.split('-', 1)[0]

        if deployment not in pods:
            pods[deployment] = list()
        pods[deployment].append(name)

        if deployment not in deployments:
            deployments[deployment] = dict()
        deployments[deployment]['os'] = os
        deployments[deployment]['status'] = status
    return pods, deployments

# Get Environment
def getInternalVariables(pod, namespace, v1, windows=False):
    resp = None
    try:
        resp = v1.read_namespaced_pod(name=pod, namespace=namespace)
        # print(resp)
    except ApiException as e:
        if e.status != 404:
            print("Unknown error: %s" % e)
            exit(1)

    exec_command = [
        '/bin/sh',
        '-c',
        'printenv'
    ]

    if(windows==True):
        exec_command = [
            'powershell',
            '-c',
            'Get-Childitem env:  | foreach { $_.Name+"="+$_.Value }'
        ]

    env = stream(
        v1.connect_get_namespaced_pod_exec,
        name=pod,
        namespace=namespace,
        command=exec_command,
        stderr=True,
        stdin=False,
        stdout=True,
        tty=False
    )
    env = env.split('\n')
    data = dict()
    for e in env:
        if e != '':
            key = e.split('=')[0]
            value = e.split('=')[1]
            data[key] = value
    return data

# Get Services
def getServices(namespace, v1):
    ret = v1.list_namespaced_service(namespace, watch=False)
    data = dict()
    for i in ret.items:
        item_data = dict()
        item_data['type'] = i.spec.type
        item_data['link'] = i.metadata.self_link
        # item_data['status'] = i.spec.status
        item_data['dns'] = i.metadata.name+'.'+i.metadata.namespace+'.svc.cluster.local'
        data[i.metadata.name] = item_data
    return data

# Get Logs
def getLogs(pod, namespace, v1):
    logs = None
    try:
        api_instance = client.CoreV1Api()
        api_response = api_instance.read_namespaced_pod_log(name=pod, namespace=namespace)
        logs = api_response
        print(len(logs.encode('utf-8'))/(1024*1024),'KB')
        if(len(logs)>1024*1024):
            logs = logs[-1024*1024:]
    except ApiException as e:
        logs = 'Found exception in reading the logs'
    return logs

def getSecret(namespace, secret, v1):
    sec = v1.read_namespaced_secret(secret, namespace).data
    # pas = base64.b64decode(sec.strip().split()[1].translate(None, '}\''))
    return sec