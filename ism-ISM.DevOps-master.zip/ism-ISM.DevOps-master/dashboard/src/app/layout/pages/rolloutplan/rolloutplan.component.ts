import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import { LogsService } from 'src/app/services/apis/logs.service';
import { LoaderService } from 'src/app/services/controls/loader.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rolloutplan',
  templateUrl: './rolloutplan.component.html',
  styleUrls: ['./rolloutplan.component.scss']
})
export class RolloutplanComponent implements OnInit {

  constructor(
    public api: LogsService,
    public loader: LoaderService,
    public fb: FormBuilder,
    private route: Router,
  ) {
    this.checkList = fb.group({
      pepperoni: false,
      extracheese: false,
      mushroom: false,
    });
  }

  ngOnInit(): void {
    this.get_tracked();
    this.get_workflow();
  }

  workflow = new Array();
  tracked = new Map();
  tracked_keys = new Array();
  ready = false;
  trackCache = new Map();
  checkList: any;


  drop(event: any) {
    moveItemInArray(this.workflow, event.previousIndex, event.currentIndex);
  }

  get_trackingInfo(id: any) {
    this.api.getTrackingInfo(id).subscribe(
      (data: any) => {
        this.trackCache.set(Number(id), data);
      }
    );
  }

  get_tracked() {
    this.loader.show();
    this.api.getTracked().subscribe(
      (data: any) => {
        console.log(data)
        Object.keys(data).forEach((element: any) => {
          // this.workflow.push(data[element]);
          this.tracked_keys.push(Number(element));
          this.tracked.set(Number(element), data[element]);
          this.get_trackingInfo(element);
        });
        this.ready = true;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  get_workflow() {
    this.loader.show();
    this.api.getWorkflow().subscribe(
      (data: any) => {
        this.workflow = data;
        this.ready = true;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  onChange(value: any) {
    if(this.workflow.includes(value)) {
      this.workflow.splice(this.workflow.indexOf(value),1)
    } else {
      this.workflow.push(value)
    }
  }

  save_workflow() {
    this.loader.show();
    this.api.updateWorkflow(this.workflow).subscribe(
      (data: any) => {
        console.log(data)
        this.ready = true;
        this.loader.hide();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  findWF(key: any): boolean{
    console.log(this.workflow);
    console.log(this.workflow.includes(key));
    return this.workflow.includes(key);
  }

  openPlanDeploy(){
    this.route.navigate(['Deployment']);
  }

}
