import ISMLogBackend.database.auth as auth

def cappedLatest(table):
    db = auth.getDatabase()
    collection = db[table]
    data = collection.find().limit(1).sort([('$natural',-1)])
    res = []
    for row in data:
        res.append(row)
    return res

def cappedLatestFiltered(table, key, value):
    db = auth.getDatabase()
    collection = db[table]
    data = collection.find({key: value}).limit(1).sort([('$natural',-1)])
    res = []
    for row in data:
        res.append(row)
    return res[0]

def cappedLatestMultiFiltered(table, filters):
    db = auth.getDatabase()
    collection = db[table]
    data = collection.find(filters).limit(1).sort([('$natural',-1)])
    res = []
    for row in data:
        res.append(row)
    if len(res) > 0:
        return res[0]['logs']
    return []

def filterOne(table, key, value):
    db = auth.getDatabase()
    collection = db[table]
    data = collection.find_one({key: value})
    return data