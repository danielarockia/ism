export class SideCatalog {

  public active = false;
  constructor(public name: string, public icon: string) {

  }

}
