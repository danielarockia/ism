import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RolloutplanComponent } from './rolloutplan.component';

describe('RolloutplanComponent', () => {
  let component: RolloutplanComponent;
  let fixture: ComponentFixture<RolloutplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RolloutplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RolloutplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
