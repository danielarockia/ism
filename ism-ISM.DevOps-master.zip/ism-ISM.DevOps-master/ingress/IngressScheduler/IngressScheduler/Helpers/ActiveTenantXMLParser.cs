﻿using BetterConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

namespace IngressScheduler.Helpers
{
    public static class ActiveTenantXMLParser
    {
        public static List<string> Parse(String data)
        {
            List<string> activeTenants = new List<string>();

            XmlDocument xml = new XmlDocument();
            xml.LoadXml(data);

            //XmlDocument activeTenants = data -> s:Envelope, s:Body, GetActiveTenantsResponse, GetActiveTenantsResult

            XmlNodeList tenants = xml.GetElementsByTagName("GetActiveTenantsResult")[0].ChildNodes;

            Table table = new Table("SL", "Tenant", "Vanity URL");
            table.Config = TableConfiguration.MySql();

            for (int i = 0; i < tenants.Count; i++)
            {
                var node = tenants[i];
                string tenantUrl = ParseNode(node, "TenantUrl");
                List<string> vanityUrls = ParseNodeList(node, "AlternateUrls");
                foreach (string url in vanityUrls)
                {
                    activeTenants.Add(url);
                }
                table.AddRow(i + 1, tenantUrl, vanityUrls.Count());
                activeTenants.Add(tenantUrl);
            }

            Console.Write(table.ToString());

            return activeTenants;
        }

        private static string ParseNode(XmlNode Node, string Name)
        {
            var element = Node[Name];
            string value = element.InnerText;
            return value;
        }

        private static List<String> ParseNodeList(XmlNode Node, string Name)
        {
            var element = Node[Name];
            List<String> values = new List<String>();
            if (element != null)
            {
                foreach (XmlNode item in element.ChildNodes)
                {
                    values.Add(item.InnerText);
                }
            }
            return values;
        }
    }
}
