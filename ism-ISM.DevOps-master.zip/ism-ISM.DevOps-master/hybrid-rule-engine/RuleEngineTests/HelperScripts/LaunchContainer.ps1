﻿az acr login --name ismciregistry
dotnet publish ./RuleEngine/RuleEngine.sln -c release -o ./LoadBalancer/ruleengine/RuleEngine -r linux-x64 --self-contained
Copy-Item ./RuleEngineTests/bin/Debug/net6.0/RuleEngine.dll.config -Destination ./LoadBalancer/ruleengine/RuleEngine -Force
docker image rm ruleengine
docker build --no-cache -f LoadBalancer/Dockerfile_automation -t ruleengine ./LoadBalancer
docker rm -f rule-image
docker run -d --name rule-image -p 8080:80 ruleengine