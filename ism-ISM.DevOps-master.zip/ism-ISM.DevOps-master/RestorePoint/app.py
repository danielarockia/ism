from inspect import Parameter
from click import argument
from kubernetes import client, config, utils
from kubernetes.client import configuration
from flask import Flask, Response, current_app, render_template, request
import json
import subprocess
import datetime

app = Flask(__name__, template_folder='templates')

current_context = 'AKS-RG-NVZ-CI-ISM' #None
resource_list = [
    'secret',
    'deployment', 
    'service',
    'hpa',
    'ingress',
    'cronjob'
]

yaml = []

def execute(command, parameter, value, extras=[]):
    cmd_args = ["kubectl", command, parameter, value]+extras
    cmd = " ".join(cmd_args)
    result = subprocess.check_output(cmd, shell=True)
    result = result.decode()
    return result

def get_resources(name, namespace=None):
    extras = ['-o=name']
    if namespace!=None:
        extras = ['-n', namespace]+extras
    resources = execute('get', '' ,name, extras )
    resources = resources.strip().split('\n')
    res = []
    for resource in resources:
        if '/' in resource:
            res.append(resource.split('/')[1])
    return res

def export_resource(type, name, namespace=None):
    extras = ['-o=yaml']
    if namespace!=None:
        extras = ['-n', namespace]+extras
    resources = execute('get', type, name, extras )
    # res = []
    # for resource in resources:
    #     res.append(resource.split('/')[1])
    return resources

@app.route('/context', methods=['get'])
def get_context():
    contexts, active_context = config.list_kube_config_contexts()
    return render_template('select-context.html', contexts=contexts)

@app.route('/activate', methods=['POST'])
def activate():
    global current_context
    data = request.json
    current_context = data['context']
    res = execute('config', 'use-context', current_context)
    return 'OK'

@app.route('/explore', methods=['get'])
def explore():
    global current_context
    global yaml
    yaml = []
    res = get_resources('namespace')
    return render_template('resources.html', cluster=current_context, namespaces=res, resources=resource_list)

@app.route('/namespaces', methods=['get'])
def namespaces():
    res = get_resources('namespace')
    print(res)
    return json.dumps(res)

@app.route('/resources', methods=['get'])
def resources():
    data = request.args
    resource = data.get('type')
    namespace = data.get('namespace')
    res = get_resources(resource, namespace)
    print(res)
    return json.dumps(res)

@app.route('/export', methods=['get'])
def export():
    global yaml
    data = request.args
    resource = data.get('type')
    name = data.get('name')
    namespace = data.get('namespace')
    res = export_resource(resource, name, namespace)
    yaml.append(res)
    return res

@app.route('/download', methods=['get'])
def download():
    global yaml
    content = '\n---\n'.join(yaml)
    return Response(content, mimetype='text/plain')

@app.route('/save', methods=['get'])
def save():
    global yaml
    content = '\n---\n'.join(yaml)
    d = datetime.datetime.now().strftime("_%Y_%m_%d_%H_%M")
    file = open('saves/'+current_context+d+'.yaml', 'w')
    file.write(content)
    file.close()
    return Response(content, mimetype='text/plain')

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080, debug=True)