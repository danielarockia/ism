﻿using NUnit.Framework;
using RuleEngine.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngineTests.Mocks
{
    public class Settings : ISettings
    {
        public Dictionary<string, string> SettingsKeys { get; private set; }

        public Settings()
        {
            SettingsKeys = new Dictionary<string, string>();            
        }

        public string Load(string key)
        {
            if(SettingsKeys.ContainsKey(key))
            {
                return SettingsKeys[key];
            }
            else
            {
                string? runSettingsValue = TestContext.Parameters[key];
                if (runSettingsValue != null)
                    return runSettingsValue;
                throw new Exception($"Key '{key}' is missing in settings");
            }
        }
    }
}
